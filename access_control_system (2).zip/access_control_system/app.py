from flask import Flask, request
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def home():
    return "🟢 Arduino API is live!"

@app.route('/api/data', methods=['POST'])
def receive_data():
    data = request.json.get('status')
    timestamp = request.json.get('timestamp')

    print(f"Received: {data} at {timestamp}")

    # Later: you can add MySQL insert here if needed

    return {"message": "✅ Data received successfully!"}
