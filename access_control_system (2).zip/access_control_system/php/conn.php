<?php
// Check if connection already exists
if (!isset($conn) || !($conn instanceof mysqli)) {
    $host = "localhost";
    $user = "root";
    $pass = "";
    $dbname = "access_logs";

    $conn = new mysqli($host, $user, $pass, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
}
?>
