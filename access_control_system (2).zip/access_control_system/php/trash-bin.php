<?php
// Start session and check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: signlog.php");
    exit;
}

// Set cache control headers to prevent browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

// First include conn.php for database connection
include('conn.php');
// Then include log_entry.php for logging functionality
include('log_entry.php');

// Get the rejected users
$sql = "SELECT id, email, DATE(created_at) as log_date, TIME(created_at) as log_time, status 
        FROM sign_up 
        WHERE status = 'rejected' 
        ORDER BY created_at DESC 
        LIMIT 50";

$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}
$total_users = $result->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Trash Bin - Access Control System</title>
  <link rel="stylesheet" href="../cs/trash-bin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <script>
    // Prevent browser back button after logout
    // Execute immediately, don't wait for load event
    (function() {
      // Disable browser back button
      window.history.pushState(null, "", window.location.href);
      window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
      };
      
      // If back button is attempted, revalidate session immediately
      window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
          // Page was loaded from cache (back button)
          window.location.reload(); // Force reload from server
        }
      });
    })();
  </script>
</head>
<body>
  <div class="wrapper">
    <?php include 'nav.php'; ?>

    <div class="main">
      <div class="topbar">
        <div class="search-container">
          <span class="search-icon-wrapper">
            <i class="fas fa-search"></i>
          </span>
          <input type="text" class="search" placeholder="Search by email, ID, date...">
        </div>
      </div>

      <div class="content">
        <div class="header">
          <h2><?= $total_users ?> Rejected Users</h2>
        </div>

        <div class="table-container">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Date</th>
                <th>Time</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result->num_rows === 0): ?>
                <tr class="no-results">
                  <td colspan="6">No rejected users found</td>
                </tr>
              <?php else: ?>
                <?php while($row = $result->fetch_assoc()): ?>
                  <tr data-id="<?= $row['id'] ?>" data-email="<?= htmlspecialchars($row['email']) ?>">
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= $row['log_date'] ?></td>
                    <td><?= $row['log_time'] ?></td>
                    <td><?= ucfirst(htmlspecialchars($row['status'])) ?></td>
                    <td>
                      <button class="action restore-btn green" data-id="<?= $row['id'] ?>">
                        <i class="fas fa-trash-restore"></i> Restore
                      </button>
                      <button class="action permanent-delete-btn red" data-id="<?= $row['id'] ?>">
                        <i class="fas fa-times-circle"></i> Delete
                      </button>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- Modals -->
  <div id="restoreModal" class="modal">
    <div class="modal-content">
      <p>Restore this account to pending status?</p>
      <div class="modal-actions">
        <button id="confirmRestore" class="btn-confirm green-btn">Restore</button>
        <button id="cancelRestore" class="btn-cancel">Cancel</button>
      </div>
    </div>
  </div>

  <div id="permanentDeleteModal" class="modal">
    <div class="modal-content">
      <p>Are you sure you want to permanently delete this account?</p>
      <p class="warning">This action cannot be undone!</p>
      <div class="modal-actions">
        <button id="confirmPermanentDelete" class="btn-confirm red-btn">Delete</button>
        <button id="cancelPermanentDelete" class="btn-cancel">Cancel</button>
      </div>
    </div>
  </div>

  <!-- Toasts -->
  <div id="restoreToast" class="toast">Account restored!</div>
  <div id="deleteToast" class="toast">Account deleted!</div>
  
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const restoreModal = document.getElementById('restoreModal');
      const deleteModal = document.getElementById('permanentDeleteModal');
      const restoreToast = document.getElementById('restoreToast');
      const deleteToast = document.getElementById('deleteToast');
      let selectedUserId = null;
      let selectedUserEmail = null;

      // Initially hide all modals and toasts
      restoreModal.style.display = 'none';
      deleteModal.style.display = 'none';
      restoreToast.style.display = 'none';
      deleteToast.style.display = 'none';

      // Modal display helper
      function showModal(modal) {
        modal.style.display = 'flex';
      }

      function hideModal(modal) {
        modal.style.display = 'none';
      }

      function showToast(toast) {
        toast.style.display = 'block';
        setTimeout(() => {
          toast.style.display = 'none';
        }, 2000);
      }

      // Add click events to all restore buttons
      document.querySelectorAll('.restore-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          selectedUserId = this.getAttribute('data-id');
          const row = document.querySelector(`tr[data-id="${selectedUserId}"]`);
          selectedUserEmail = row.getAttribute('data-email');
          showModal(restoreModal);
        });
      });

      // Add click events to all delete buttons
      document.querySelectorAll('.permanent-delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          selectedUserId = this.getAttribute('data-id');
          const row = document.querySelector(`tr[data-id="${selectedUserId}"]`);
          selectedUserEmail = row.getAttribute('data-email');
          showModal(deleteModal);
        });
      });

      // Restore confirm
      document.getElementById('confirmRestore').addEventListener('click', () => {
        if (!selectedUserId) return;
        
        // Add log entry data
        const logData = new FormData();
        logData.append('user_id', selectedUserId);
        logData.append('status', 'pending');
        logData.append('email', selectedUserEmail);
        
        fetch('restore_user.php', {
          method: 'POST',
          body: logData
        })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            document.querySelector(`tr[data-id="${selectedUserId}"]`)?.remove();
            showToast(restoreToast);
            updateCounter();
          } else {
            alert(data.message || 'Restore failed.');
          }
          hideModal(restoreModal);
          selectedUserId = null;
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Server error.');
          hideModal(restoreModal);
        });
      });

      // Delete confirm
      document.getElementById('confirmPermanentDelete').addEventListener('click', () => {
        if (!selectedUserId) return;
        
        // Add log entry data
        const logData = new FormData();
        logData.append('user_id', selectedUserId);
        logData.append('email', selectedUserEmail);
        
        fetch('permanent_delete_user.php', {
          method: 'POST',
          body: logData
        })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            document.querySelector(`tr[data-id="${selectedUserId}"]`)?.remove();
            showToast(deleteToast);
            updateCounter();
          } else {
            alert(data.message || 'Delete failed.');
          }
          hideModal(deleteModal);
          selectedUserId = null;
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Server error.');
          hideModal(deleteModal);
        });
      });

      // Cancel buttons
      document.getElementById('cancelRestore').addEventListener('click', () => {
        hideModal(restoreModal);
      });
      
      document.getElementById('cancelPermanentDelete').addEventListener('click', () => {
        hideModal(deleteModal);
      });

      // Counter update
      function updateCounter() {
        const rows = document.querySelectorAll('tbody tr:not(.no-results)');
        document.querySelector('.header h2').textContent = `${rows.length} Rejected Users`;

        if (rows.length === 0) {
          const tbody = document.querySelector('tbody');
          const noResults = document.querySelector('.no-results');
          if (!noResults) {
            const noRow = document.createElement('tr');
            noRow.className = 'no-results';
            noRow.innerHTML = `<td colspan="6">No rejected users found</td>`;
            tbody.appendChild(noRow);
          }
        }
      }

      // Enhanced search filter
      document.querySelector('.search').addEventListener('input', function() {
        const keyword = this.value.toLowerCase();
        let count = 0;

        document.querySelectorAll('tbody tr').forEach(row => {
          if (row.classList.contains('no-results') || row.classList.contains('no-results-search')) {
            row.style.display = 'none';
            return;
          }
          
          const visible = row.textContent.toLowerCase().includes(keyword);
          row.style.display = visible ? '' : 'none';
          if (visible) count++;
        });

        const existing = document.querySelector('.no-results-search');
        if (count === 0 && !existing) {
          const tbody = document.querySelector('tbody');
          const tr = document.createElement('tr');
          tr.className = 'no-results-search';
          tr.innerHTML = `<td colspan="6">No matching results found</td>`;
          tbody.appendChild(tr);
        } else if (count > 0 && existing) {
          existing.remove();
        }
        
        // Show the original no-results row if search is empty and there are no records
        const noResults = document.querySelector('.no-results');
        if (this.value === '' && document.querySelectorAll('tbody tr:not(.no-results):not(.no-results-search)').length === 0 && noResults) {
          noResults.style.display = '';
        }
      });
    });
  </script>
</body>
</html>