<?php
// First, you need to install PHPMailer via composer:
// composer require phpmailer/phpmailer

// Include PHPMailer classes at the top of forgotpass.php and resend_otp.php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Make sure you have the Composer autoloader included
require '../vendor/autoload.php';

/**
 * Function to send emails using PHPMailer
 * 
 * @param string $to Recipient email
 * @param string $subject Email subject
 * @param string $htmlMessage HTML formatted email body
 * @return bool True on success, false on failure
 */
function sendEmail($to, $subject, $htmlMessage) {
    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER; // Enable verbose debug output (for testing only)
        $mail->isSMTP();                          // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';     // Set the SMTP server to send through (change to your provider)
        $mail->SMTPAuth   = true;                 // Enable SMTP authentication
        $mail->Username   = 'bryancasipe38@gmail.com'; // SMTP username
        $mail->Password   = 'cdgb kksa orll jbhx';  // SMTP password (use app password for Gmail)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
        $mail->Port       = 587;                  // TCP port to connect to
        
        // Recipients
        $mail->setFrom('your-email@gmail.com', 'Your Website Name');
        $mail->addAddress($to);                   // Add a recipient
        
        // Content
        $mail->isHTML(true);                      // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body    = $htmlMessage;
        $mail->AltBody = strip_tags($htmlMessage); // Plain text alternative
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>