<?php
include_once('conn.php'); // Use include_once to avoid duplicate connection

// Only execute this part if it's a direct POST request to this file
if ($_SERVER["REQUEST_METHOD"] === "POST" && basename($_SERVER['PHP_SELF']) == 'log_entry.php') {
    $status = $_POST["status"] ?? '';
    $date   = $_POST["date"] ?? '';

    if ($status && $date) {
        $stmt = $conn->prepare("INSERT INTO logs (status, date) VALUES (?, ?)");
        $stmt->bind_param("ss", $status, $date);

        if ($stmt->execute()) {
            echo "✅ Log recorded in MySQL!";
        } else {
            echo "❌ Database Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "⚠️ Missing Fields!";
    }
    
    // Only close the connection when directly accessing this file
    if (basename($_SERVER['PHP_SELF']) == 'log_entry.php') {
        $conn->close();
    }
}

/**
 * Logs an action in the system
 * 
 * @param string $action The action being performed
 * @param int $userId The ID of the user performing the action (optional)
 * @param string $details Additional details about the action (optional)
 * @return bool True if the log was created successfully, false otherwise
 */
function log_action($action, $userId = null, $details = null) {
    global $conn;
    
    // Create log_entries table if it doesn't exist
    $sqlCheck = "SHOW TABLES LIKE 'log_entries'";
    $resultCheck = $conn->query($sqlCheck);
    if ($resultCheck->num_rows == 0) {
        // Table doesn't exist, create it
        $sqlCreate = "CREATE TABLE log_entries (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            action VARCHAR(255) NOT NULL,
            details TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            ip_address VARCHAR(45)
        )";
        $conn->query($sqlCreate);
    }
    
    // Get the client's IP address
    $ipAddress = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'Unknown';
    
    // Insert log entry
    $sql = "INSERT INTO log_entries (user_id, action, details, ip_address) 
            VALUES (?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $userId, $action, $details, $ipAddress);
    
    $success = $stmt->execute();
    $stmt->close();
    
    return $success;
}
?>
