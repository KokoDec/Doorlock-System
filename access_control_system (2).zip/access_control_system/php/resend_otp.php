<?php
// resend_otp.php
include('conn.php'); // Database connection
session_start(); // Start session for OTP verification

// Function to generate random OTP
function generateOTP($length = 6) {
    return substr(str_shuffle("0123456789"), 0, $length);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    
    // Sanitize input
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    
    // Check if user exists and is approved
    $stmt = $conn->prepare("SELECT * FROM sign_up WHERE email = ? AND status = 'approved'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // User exists and is approved
        $user = $result->fetch_assoc();
        
        // Generate new OTP
        $otp = generateOTP();
        $otp_expiry = date('Y-m-d H:i:s', strtotime('+10 minutes')); // OTP valid for 10 minutes
        
        // Store OTP in session
        $_SESSION['otp_data'] = [
            'email' => $email,
            'otp' => $otp,
            'expiry' => $otp_expiry
        ];
        
        // Include PHPMailer
        require_once 'email_sender.php';

        $to = $email;
        $subject = "Password Reset Verification Code";
        
        // Format the email with HTML
        $message = "
        <html>
        <head>
        <title>Password Reset Verification Code</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
            .header { background-color: #4CAF50; color: white; padding: 10px; text-align: center; border-radius: 5px 5px 0 0; }
            .content { padding: 20px; }
            .otp { font-size: 24px; font-weight: bold; text-align: center; margin: 20px 0; letter-spacing: 5px; }
            .footer { font-size: 12px; color: #777; margin-top: 20px; text-align: center; }
        </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>Password Reset Verification</h2>
                </div>
                <div class='content'>
                    <p>Hello,</p>
                    <p>You have requested a new verification code. Please use the following code to complete the password reset process:</p>
                    <div class='otp'>$otp</div>
                    <p>This code will expire in 10 minutes.</p>
                    <p>If you did not request this change, please ignore this email or contact support if you have concerns.</p>
                </div>
                <div class='footer'>
                    <p>This is an automated message, please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Send the email using PHPMailer
        if(sendEmail($to, $subject, $message)) {
            echo "success";
        } else {
            echo "error";
        }
    } else {
        echo "invalid_email";
    }
} else {
    // Direct access not allowed
    header("Location: forgotpass.php");
    exit;
}
?>