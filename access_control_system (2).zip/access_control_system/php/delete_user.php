<?php
// This script handles deletion of users from the logs page
include('conn.php');

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Return JSON for AJAX requests
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    } else {
        header('Location: logs.php');
    }
    exit;
}

// Validate inputs
if (!isset($_POST['user_id'])) {
    // Return JSON for AJAX requests
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Missing user ID']);
    } else {
        header('Location: logs.php?error=Missing+user+ID');
    }
    exit;
}

$user_id = intval($_POST['user_id']);

// Update user status to deleted
$stmt = $conn->prepare("UPDATE sign_up SET status = 'deleted' WHERE id = ?");
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    // Return JSON for AJAX requests
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
    } else {
        header('Location: logs.php?success=User+deleted');
    }
} else {
    // Return JSON for AJAX requests
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Database error']);
    } else {
        header('Location: logs.php?error=Database+error');
    }
}

$stmt->close();
$conn->close();
?> 