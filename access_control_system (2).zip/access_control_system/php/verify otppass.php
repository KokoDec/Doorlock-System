<?php
// verify_otppass.php - Handles OTP verification and redirects to change password page
include('conn.php'); // Database connection
session_start(); // Start session for OTP verification

// Check if OTP data exists in session
if (!isset($_SESSION['otp_data'])) {
    header("Location: forgotpass.php?message=" . urlencode("Session expired. Please request a new verification code."));
    exit;
}

// Get OTP data from session
$otp_data = $_SESSION['otp_data'];
$stored_otp = $otp_data['otp'];
$stored_email = $otp_data['email'];
$expiry_time = $otp_data['expiry'];

// Check if OTP has expired
if (date('Y-m-d H:i:s') > $expiry_time) {
    unset($_SESSION['otp_data']); // Clear expired OTP
    header("Location: forgotpass.php?message=" . urlencode("Verification code has expired. Please request a new one."));
    exit;
}

// Get submitted OTP and email
$email = $_POST['email'];
$submitted_otp = '';

// Combine OTP digits
if (isset($_POST['otp']) && is_array($_POST['otp'])) {
    foreach ($_POST['otp'] as $digit) {
        $submitted_otp .= $digit;
    }
}

// Validate OTP
if ($submitted_otp === $stored_otp && $email === $stored_email) {
    // OTP is valid - set verification flag in session
    $_SESSION['otp_verified'] = true;
    
    // Redirect to change password page
    header("Location: change_password.php?email=" . urlencode($email));
    exit;
} else {
    // Invalid OTP
    header("Location: otppage.php?email=" . urlencode($email) . "&message=" . urlencode("Invalid verification code. Please try again."));
    exit;
}
?>