<?php
// email_sender.php
// This file contains the email sending functionality using PHPMailer

// You need to install PHPMailer via composer:
// composer require phpmailer/phpmailer

// If you don't have Composer installed, you can also download PHPMailer manually from:
// https://github.com/PHPMailer/PHPMailer

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Check if Composer autoloader exists
if (file_exists('../vendor/autoload.php')) {
    require '../vendor/autoload.php';
} else {
    // Manual includes if composer is not used
    // Make sure to download PHPMailer and adjust the path accordingly
    require '../PHPMailer/src/Exception.php';
    require '../PHPMailer/src/PHPMailer.php';
    require '../PHPMailer/src/SMTP.php';
}

/**
 * Function to send emails using PHPMailer
 * 
 * @param string $to Recipient email
 * @param string $subject Email subject
 * @param string $htmlMessage HTML formatted email body
 * @return bool True on success, false on failure
 */
function sendEmail($to, $subject, $htmlMessage) {
    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        // Uncomment for debugging
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        
        $mail->isSMTP();                          // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';     // Set the SMTP server (change to your provider)
        $mail->SMTPAuth   = true;                 // Enable SMTP authentication
        $mail->Username   = 'bryancasipe38@gmail.com'; // SMTP username
        $mail->Password   = 'cdgb kksa orll jbhx';  // SMTP password (App password for Gmail)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
        $mail->Port       = 587;                  // TCP port to connect to
        
        // Recipients
        $mail->setFrom('your-email@gmail.com', 'Your Website Name');
        $mail->addAddress($to);                   // Add a recipient
        
        // Content
        $mail->isHTML(true);                      // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body    = $htmlMessage;
        $mail->AltBody = strip_tags($htmlMessage); // Plain text alternative
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        // Log the error for debugging
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}

/**
 * Alternative function that uses PHP's mail() function as a fallback
 * Use this if you can't set up PHPMailer but have mail() configured on your server
 */
function sendEmailFallback($to, $subject, $htmlMessage) {
    // Headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: Your Website <noreply@yourwebsite.com>' . "\r\n";
    
    // Send email
    return mail($to, $subject, $htmlMessage, $headers);
}
?>