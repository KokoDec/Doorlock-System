<?php
// change_password.php
include('conn.php'); // Database connection
session_start(); // Start the session to check OTP verification

// Check if OTP verification is completed
if (!isset($_SESSION['otp_verified']) || $_SESSION['otp_verified'] !== true) {
    header("Location: forgotpass.php?message=OTP verification required.");
    exit;
}

// Get email from query parameter
$email = isset($_GET['email']) ? $_GET['email'] : '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Sanitize inputs
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    
    if ($new_password !== $confirm_password) {
        header("Location: changepassword.php?email=" . urlencode($email) . "&message=Passwords do not match!");
        exit;
    }
    
    // Check if user exists and is approved
    $stmt = $conn->prepare("SELECT * FROM sign_up WHERE email = ? AND status = 'approved'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Hash the password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        // Update the password
        $update = $conn->prepare("UPDATE sign_up SET password = ? WHERE email = ?");
        $update->bind_param("ss", $hashed_password, $email);
        $update->execute();
        
        // Clear session data
        unset($_SESSION['otp_data']);
        unset($_SESSION['otp_verified']);
        
        // Show success message
        $success = true;
    } else {
        header("Location: changepassword.php?email=" . urlencode($email) . "&message=No approved account found with this email.");
        exit;
    }
}
?>
<?php if (isset($success) && $success): ?>
<div class="modal" style="display: flex;">
    <div class="modal-content">
        <div class="success-icon">&#10004;</div>
        <h2>Password Changed Successfully!</h2>
        <p>Your password has been updated. You can now login with your new password.</p>
        <a href="signlog.php">
            <button class="modal-button">Go to Login</button>
        </a>
    </div>
</div>
<?php endif; ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Change Password</title>
  <link rel="stylesheet" href="../cs/forgot.css" />

  <!-- Font Awesome CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    body {
      background-color:#0333a4;
    }
    .left-panel {
      background-color: #0333a4 !important;
      color: white;
    }
    .left-panel h1,
    .left-panel p {
      color: white;
    }
    .login-image {
      background-color: #0333a4;
      display: block;
    }
    .main-container {
      background-color: #0333a4;
    }
  </style>
</head>
<body>
  <div class="main-container">
    
    <!-- Left Panel -->
    <div class="left-panel" style="background-color: #0333a4 !important;">
      <img src="../pictures/2.png" alt="Change Illustration" class="login-image" style="background-color: #0333a4;" />
      <h1>Your Digital Key Starts Here.</h1>
      <p>Change your password securely and regain access to your account.</p>
    </div>

    <!-- Right Panel -->
    <div class="right-panel">
      <form class="login-form" id="change-form" method="POST" action="change_password.php">
        <h2>Change Password</h2>
        <div class="form-body">
          <label for="change-email">E-mail</label>
          <input type="email" id="change-email" name="email" value="<?php echo htmlspecialchars($email); ?>" readonly />

          <label for="new-password">New Password</label>
          <div class="password-field">
            <input type="password" id="new-password" name="new_password" placeholder="Enter new password" required oninput="checkPasswordStrength()" />
            <span class="toggle-eye" onclick="togglePassword('new-password', this)">
              <i class="fas fa-eye"></i>
            </span>
          </div>
          <div id="password-requirements" class="password-requirements">
            <ul>
              <li id="length" class="invalid">At least 8 characters</li>
              <li id="uppercase" class="invalid">One uppercase letter</li>
              <li id="lowercase" class="invalid">One lowercase letter</li>
              <li id="digit" class="invalid">One digit (0-9)</li>
              <li id="special" class="invalid">One special character (!@#$...)</li>
            </ul>
          </div>

          <label for="confirm-password">Confirm Password</label>
          <div class="password-field">
            <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirm new password" required oninput="checkPasswordMatch()" />
            <span class="toggle-eye" onclick="togglePassword('confirm-password', this)">
              <i class="fas fa-eye"></i>
            </span>
          </div>
          <div id="password-match" class="password-match"></div>

          <button type="submit" id="submit-btn" class="submit-btn" disabled>Change Password</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Success Modal -->
  <div id="success-modal" class="modal">
    <div class="modal-content">
      <div class="success-icon">
        <i class="fas fa-check-circle"></i>
      </div>
      <h2>Password Changed Successfully!</h2>
      <p>Your password has been updated. You can now login with your new password.</p>
      <button class="modal-button" onclick="window.location.href='signlog.php'">Go to Login</button>
    </div>
  </div>

  <!-- Notification Message -->
  <div id="message-notification" class="hidden">
    <p id="message-text"></p>
    <span id="close-message" class="close-btn">&times;</span>
  </div>

  <script>
    // Toggle password visibility
    function togglePassword(inputId, iconElement) {
      const input = document.getElementById(inputId);
      const icon = iconElement.querySelector('i');
      
      if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
      } else {
        input.type = "password";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
      }
    }

    // Check password strength
    function checkPasswordStrength() {
      const password = document.getElementById('new-password').value;
      const confirmPassword = document.getElementById('confirm-password').value;
      let isValid = true;

      // Check length
      const lengthValid = password.length >= 8;
      document.getElementById('length').className = lengthValid ? 'valid' : 'invalid';
      isValid = isValid && lengthValid;

      // Check uppercase
      const uppercaseValid = /[A-Z]/.test(password);
      document.getElementById('uppercase').className = uppercaseValid ? 'valid' : 'invalid';
      isValid = isValid && uppercaseValid;

      // Check lowercase
      const lowercaseValid = /[a-z]/.test(password);
      document.getElementById('lowercase').className = lowercaseValid ? 'valid' : 'invalid';
      isValid = isValid && lowercaseValid;

      // Check digit
      const digitValid = /\d/.test(password);
      document.getElementById('digit').className = digitValid ? 'valid' : 'invalid';
      isValid = isValid && digitValid;

      // Check special character
      const specialValid = /[!@#$%^&*()_+,.?":{}|<>]/.test(password);
      document.getElementById('special').className = specialValid ? 'valid' : 'invalid';
      isValid = isValid && specialValid;

      // Check if passwords match if confirm password has a value
      if (confirmPassword) {
        const passwordsMatch = password === confirmPassword;
        isValid = isValid && passwordsMatch;
      }

      // Update submit button state
      document.getElementById('submit-btn').disabled = !isValid || 
        (confirmPassword && password !== confirmPassword);

      // Also check password match if confirm password field has value
      if (confirmPassword) {
        checkPasswordMatch();
      }
    }

    // Check if passwords match
    function checkPasswordMatch() {
      const password = document.getElementById('new-password').value;
      const confirmPassword = document.getElementById('confirm-password').value;
      const matchElement = document.getElementById('password-match');
      
      if (confirmPassword) {
        if (password === confirmPassword) {
          matchElement.innerHTML = '<span class="match-valid"><i class="fas fa-check"></i> Passwords match</span>';
          
          // Only enable submit if all password requirements are met
          const allRequirementsMet = document.querySelectorAll('#password-requirements .invalid').length === 0;
          document.getElementById('submit-btn').disabled = !allRequirementsMet;
        } else {
          matchElement.innerHTML = '<span class="match-invalid"><i class="fas fa-times"></i> Passwords do not match</span>';
          document.getElementById('submit-btn').disabled = true;
        }
      } else {
        matchElement.innerHTML = '';
      }
      
      // Also re-check password strength to keep everything in sync
      checkPasswordStrength();
    }

    // Show success or error notification
    function showMessage(message, isError = false) {
      const notification = document.getElementById('message-notification');
      const messageText = document.getElementById('message-text');
      const closeButton = document.getElementById('close-message');

      messageText.innerText = message;
      notification.style.backgroundColor = isError ? '#f44336' : '#4CAF50'; // Red for error, green for success
      notification.classList.remove('hidden');
      notification.classList.add('visible');

      // Close button functionality
      closeButton.onclick = function() {
        notification.classList.add('hidden');
      };

      // Optional: Automatically hide after 5 seconds
      setTimeout(function() {
        notification.classList.add('hidden');
      }, 5000);
    }

    // Check URL message and show it on page load
    window.onload = function() {
      const urlParams = new URLSearchParams(window.location.search);
      const message = urlParams.get('message');
      
      <?php if (isset($success) && $success): ?>
      // Show success modal
      const modal = document.getElementById('success-modal');
      modal.style.display = 'flex';
      <?php endif; ?>
      
      if (message) {
        showMessage(decodeURIComponent(message), 
          message.includes("do not match") || 
          message.includes("No approved"));
      }
    };
  </script>
</body>
</html>