<?php
// Start session and check if user is already logged in
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Sign Up Page</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
  <link rel="stylesheet" href="../cs/signup.css" />
  <style>
    /* Larger OTP modal */
    #popup-otp .popup-content {
      width: 400px;
      max-width: 95%;
      padding: 30px 20px;
    }
    
    @media (max-width: 480px) {
      #popup-otp .popup-content {
        width: 90%;
      }
    }
  </style>
</head>
<body>
  <div class="main-container">
    <!-- Left Panel -->
    <div class="left-panel">
      <div class="left-panel-content">
        <div class="content-top">
          <h1>Your Smart Entry Begins Here.</h1>
          <p>
            Sign Up to create your digital key and access<br />
            your smart door with ease and security.
          </p>
        </div>
        <div class="image-container">
          <img src="../pictures/2.png" alt="Login Illustration" class="login-image" />
        </div>
      </div>
    </div>

    <!-- Right Panel with Form -->
    <div class="right-panel">
      <form class="login-form" id="signup-form">
        <h2>Sign Up</h2>
        <div class="form-body">
          <label for="signup-email">E-mail</label>
          <input type="email" id="signup-email" name="email" placeholder="Enter your email" required />

          <label for="signup-password">Password</label>
          <div class="password-field">
            <input type="password" id="signup-password" name="password" placeholder="Enter your password" required />
            <span class="toggle-eye" onclick="togglePassword(this)">
              <i class="fas fa-eye"></i>
            </span>
          </div>

          <ul class="password-checklist">
            <li id="length" class="invalid">At least 8 characters</li>
            <li id="uppercase" class="invalid">One uppercase letter</li>
            <li id="lowercase" class="invalid">One lowercase letter</li>
            <li id="number" class="invalid">One digit (0-9)</li>
            <li id="symbol" class="invalid">One symbol (!@#$...)</li>
          </ul>

          <label for="confirm-password">Confirm Password</label>
          <div class="password-field">
            <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirm your password" required />
            <span class="toggle-eye" onclick="togglePassword(this)">
              <i class="fas fa-eye"></i>
            </span>
          </div>

          <button type="submit" class="submit-btn">SIGN UP</button>
        </div>
      </form>

      <div class="already-account">
        <a href="signlog.php">Already have an account?</a>
      </div>
      <div class="terms">
        <a href="#" id="open-terms">Terms and Conditions</a>
      </div>
    </div>
  </div>

  <!-- Popups -->
  <div id="popup-success" class="popup hidden">
    <div class="popup-content">
      <h3>✅ Sign Up Successful!</h3>
      <p>You can now log in with your new account.</p>
      <button onclick="closePopup()">Close</button>
    </div>
  </div>

  <div id="popup-error" class="popup hidden">
    <div class="popup-content">
      <h3 style="color: red;">⚠️ Error</h3>
      <p id="error-message"></p>
      <button onclick="closeErrorPopup()">Close</button>
    </div>
  </div>

  <div id="popup-otp" class="popup hidden">
    <div class="popup-content">
      <h3>🔐 Enter OTP</h3>
      <input type="text" id="otp-input" placeholder="Enter OTP" style="font-size: 18px; padding: 12px; width: 80%; margin: 15px auto;" />
      <div style="display: flex; justify-content: space-between; width: 80%; margin: 15px auto;">
        <button onclick="resendOTP()" style="background-color: #f0f0f0; color: #333; flex: 0.48;">Resend Code</button>
        <button onclick="verifyOTP()" style="flex: 0.48;">Verify</button>
      </div>
    </div>
  </div>

  <!-- Terms Modal -->
  <div id="terms-modal" class="modal hidden">
    <div class="modal-content">
      <span class="close-button" id="close-terms">&times;</span>
      <p><strong>Terms and Conditions</strong></p>
<p><strong>Effective Date:</strong></p>
<p>
Welcome to the Door Lock Web Admin. These Terms and Conditions ("Terms") govern your
access to and use of our website and all features, technologies, and content we provide
(collectively, the "Services"). By accessing, creating an account, or using our Services in any
way, you agree to these Terms. If you do not agree, please do not use our Services.
</p>

<br>

<p><strong>Account Registration and Responsibilities</strong></p>
<p>
As an administrator overseeing the Services—particularly those involving smart door access
control—you are responsible for ensuring that all user accounts are registered with accurate,
current, and complete information. You must verify the integrity of user data during registration
and confirm that users maintain up-to-date profiles.
</p>
<p>
Before gaining access to the website or any system functionality, explicit permission from a
higher-level administrator is required. No admin or user should be granted access without
proper approval and documentation of said authorization.
</p>
<p>
Admins must enforce strict account confidentiality protocols. This includes monitoring for any
signs of credential sharing and ensuring that users do not disclose their usernames or
passwords to others.
</p>
<p>
It is your duty to promptly respond to and investigate any reports of unauthorized account
activity or security breaches. Appropriate actions, such as locking accounts, resetting
passwords, or escalating to security teams, must be taken immediately to mitigate potential
risks.
</p>
<p>
Failure to uphold these standards may compromise system integrity and will be subject to
review and possible administrative action.
</p>

<br>

<p><strong>Permitted Use of Services</strong></p>
<p>
The Door Lock Web Admin uses a secure three-step login process: username/password login,
email code verification, and approval from a high-level administrator. Access to the Admin
Dashboard is granted only after completing all steps.
</p>
<p>
Every successful login is recorded in the dashboard, including the exact time and date of
access, for tracking and monitoring purposes. All admin actions are also logged with
timestamps.
</p>

<br>

<p><strong>User-Generated Input and Password Security</strong></p>
<p>
As part of administering the Door Lock Web platform, administrators are responsible for
overseeing the secure creation, storage, and management of user-generated passwords and
PINs used to control smart door systems.
</p>
<p>
Passwords and PINs are classified as sensitive user-generated content and are fundamental to
the security of both the individual user's system and the platform as a whole.
</p>
<p>
Admins must enforce the following policies:
<ul>
  <li>Ensure that users set strong, complex passwords or PINs during registration or device setup.</li>
  <li>Actively discourage the use of weak, common, or misleading passwords (e.g., "1234", "admin", or device serial numbers).</li>
  <li>Prevent password reuse across multiple accounts or devices, where possible.</li>
  <li>Immediately revoke or reset access credentials if shared with unauthorized users or compromised in any way.</li>
</ul>
</p>

<br>

<p><strong>Ownership and Intellectual Property</strong></p>
<p>
All elements of the Door Lock System, including but not limited to the software code, user
interface, content, logos, trademarks, system designs, and underlying technology, are the
exclusive property of Admin door login or are used under license from third parties. Users are
granted a limited, non-exclusive, and non-transferable license to access and use the system
solely for authorized, non-commercial purposes. Any modification, reproduction, redistribution,
republication, or creation of derivative works based on our system or intellectual property is
strictly prohibited without our prior written consent.
</p>

<br>

<p><strong>Privacy and Data Usage</strong></p>
<p>
We take your privacy seriously. By using the Services, you agree to the collection, storage, and
processing of your personal data, including login credentials, usage activity, and device
interaction data. This information is used to operate and improve the Services, ensure security,
and comply with legal obligations. For details on how we handle your data, please refer to our
Privacy Policy, which is incorporated into these Terms by reference.
</p>

<br>

<p><strong>Service Availability and System Performance</strong></p>
<p>
We aim to provide consistent, high-quality access to the Services. However, we do not
guarantee that the Services will be available at all times or that access will be uninterrupted or
error-free. The system may occasionally become unavailable due to maintenance, updates,
technical failures, or circumstances beyond our control. While we strive to resolve such issues
promptly, we disclaim any liability for delays, interruptions, or temporary outages.
</p>

<br>

<p><strong>Limitation of Liability</strong></p>
<p>
To the fullest extent permitted by law, Door Lock Web Admins are not liable for any direct,
indirect, incidental, consequential, or special damages arising from use of the Services. This
includes issues such as unauthorized access, data loss, system failures, or any
physical/property damage from smart door malfunctions.
</p>
<p>
Admins are responsible for ensuring all devices are installed and managed securely and
lawfully. This includes:
<ul>
  <li>Using strong, non-misleading passwords or PINs.</li>
  <li>Keeping login credentials secure and confidential.</li>
  <li>Following recovery protocols if access is lost.</li>
</ul>
</p>
<p>
If an admin forgets their password or creates a misleading one that results in access issues,
delays, or security vulnerabilities, they are solely responsible for the outcome.
</p>

<br>

<p><strong>Suspension and Termination of Access</strong></p>
<p>
We reserve the right to suspend or terminate your account or restrict access to the Services at
our sole discretion, without prior notice, if you violate these Terms or engage in any activity that
compromises the integrity, safety, or security of our platform or users. You may terminate your
account at any time by contacting us or through the account settings panel on the website or
app. Upon termination, your access to Door Lock Web Admin and related data may be
permanently removed.
</p>

<br>

<p><strong>Updates and Modifications to Terms</strong></p>
<p>
We may update these Terms from time to time to reflect changes in our business, technology, or
legal obligations. Any material changes will be communicated to you via email, in-app
notifications, or posted directly on our website. Continued use of the Services after such
changes take effect constitutes your agreement to the revised Terms.
</p>

<br>

<p><strong>Jurisdiction and Governing Law</strong></p>
<p>
These Terms are governed by and construed in accordance with the laws of the Republic of the
Philippines. By using the Services, you agree to submit to the exclusive jurisdiction of the courts
located in the Philippines in the event of any dispute, claim, or legal proceeding arising under or
related to these Terms.
</p>

<br>

<p><strong>Contact Information</strong><br>
Admin door login / <a href="mailto:bryancasipe38@gmail.com">bryancasipe38@gmail.com</a>
</p>

    </div>
  </div>

  <script>
    // Password toggle
    function togglePassword(icon) {
      const input = icon.previousElementSibling;
      const isPasswordVisible = input.type === "password";
      input.type = isPasswordVisible ? "text" : "password";
      icon.innerHTML = isPasswordVisible ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
      icon.classList.toggle('clicked');
    }

    // Password validation
    const passwordInput = document.getElementById("signup-password");
    passwordInput.addEventListener("input", function () {
      const value = passwordInput.value;
      document.getElementById("length").className = value.length >= 8 ? "valid" : "invalid";
      document.getElementById("uppercase").className = /[A-Z]/.test(value) ? "valid" : "invalid";
      document.getElementById("lowercase").className = /[a-z]/.test(value) ? "valid" : "invalid";
      document.getElementById("number").className = /\d/.test(value) ? "valid" : "invalid";
      document.getElementById("symbol").className = /[\W_]/.test(value) ? "valid" : "invalid";
    });

    // Handle sign-up
    document.getElementById("signup-form").addEventListener("submit", function (e) {
      e.preventDefault();
      const email = document.getElementById("signup-email").value;
      const password = document.getElementById("signup-password").value;
      const confirmPassword = document.getElementById("confirm-password").value;

      if (password !== confirmPassword) {
        document.getElementById("error-message").textContent = "Passwords do not match.";
        document.getElementById("popup-error").classList.remove("hidden");
        return;
      }

      fetch("send_otp.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
      })
      .then(res => res.text())
      .then(data => {
        if (data.trim() === "otp_sent") {
          window.userEmail = email;
          window.userPassword = password; // Store password for resend operation
          document.getElementById("popup-otp").classList.remove("hidden");
        } else {
          document.getElementById("error-message").textContent = data;
          document.getElementById("popup-error").classList.remove("hidden");
        }
      });
    });

    function verifyOTP() {
      const otp = document.getElementById("otp-input").value;
      const email = window.userEmail;
      
      if (!otp) {
        alert("Please enter the OTP code.");
        return;
      }

      fetch("verify_otp.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `email=${encodeURIComponent(email)}&otp=${encodeURIComponent(otp)}`
      })
      .then(res => res.text())
      .then(data => {
        if (data.trim() === "OTP_verified") {
          document.getElementById("popup-otp").classList.add("hidden");
          document.getElementById("popup-success").classList.remove("hidden");
        } else {
          alert(data);
        }
      });
    }

    function resendOTP() {
      const email = window.userEmail;
      const password = window.userPassword || ''; // Get stored password or empty string as fallback
      
      if (!email) {
        alert("Email not found. Please try again.");
        return;
      }
      
      fetch("send_otp.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}&resend=true`
      })
      .then(res => res.text())
      .then(data => {
        if (data.trim() === "otp_sent") {
          alert("A new OTP has been sent to your email.");
        } else {
          alert("Failed to resend OTP: " + data);
        }
      })
      .catch(err => {
        alert("Error: " + err);
      });
    }

    function closePopup() {
      document.getElementById("popup-success").classList.add("hidden");
      document.getElementById("signup-form").reset();
      document.querySelectorAll(".password-checklist li").forEach(li => li.className = "invalid");
    }

    function closeErrorPopup() {
      document.getElementById("popup-error").classList.add("hidden");
    }

    // Modal functionality
    document.getElementById("open-terms").addEventListener("click", function () {
      document.getElementById("terms-modal").classList.remove("hidden");
    });
    document.getElementById("close-terms").addEventListener("click", function () {
      document.getElementById("terms-modal").classList.add("hidden");
    });
    window.addEventListener("click", function (e) {
      const modal = document.getElementById("terms-modal");
      if (e.target === modal) modal.classList.add("hidden");
    });
  </script>
</body>
</html>
