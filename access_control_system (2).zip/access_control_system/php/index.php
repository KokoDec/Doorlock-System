<?php
// Start the session at the very beginning
session_start();

// Check if user is logged in, if not redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: signlog.php");
    exit;
}

// Check if session has expired (30 minute timeout)
$session_timeout = 30 * 60; // 30 minutes in seconds
if (!isset($_SESSION['last_activity']) || (time() - $_SESSION['last_activity'] > $session_timeout)) {
    // Session has expired, destroy it and redirect to login
    session_unset();
    session_destroy();
    header("Location: signlog.php?message=" . urlencode("Your session has expired. Please log in again."));
    exit;
}

// Update last activity timestamp
$_SESSION['last_activity'] = time();

// Set cache control headers to prevent browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

// First include the database connection
include 'conn.php';
// Then include the logging functionality
include 'log_entry.php';

// Create log_entries table if it doesn't exist
$sql_check_log_table = "SHOW TABLES LIKE 'log_entries'";
$result_check = $conn->query($sql_check_log_table);
if ($result_check && $result_check->num_rows == 0) {
    // Table doesn't exist, create it
    $sql_create_log = "CREATE TABLE log_entries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        action VARCHAR(255) NOT NULL,
        details TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        ip_address VARCHAR(45)
    )";
    $conn->query($sql_create_log);
}

// Create weblog table if it doesn't exist
$sql_check_weblog = "SHOW TABLES LIKE 'weblog'";
$result_weblog_check = $conn->query($sql_check_weblog);
if ($result_weblog_check && $result_weblog_check->num_rows == 0) {
    // Table doesn't exist, create it
    $sql_create_weblog = "CREATE TABLE weblog (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        access_time DATETIME DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($sql_create_weblog);
    
    // Insert some sample data
    $sample_emails = ['user1@example.com', 'user2@example.com', 'admin@example.com'];
    foreach ($sample_emails as $email) {
        // Random time within the last 24 hours
        $hours = rand(0, 23);
        $minutes = rand(0, 59);
        $seconds = rand(0, 59);
        $time_offset = $hours * 3600 + $minutes * 60 + $seconds;
        $access_time = date('Y-m-d H:i:s', time() - $time_offset);
        
        $sql_insert = "INSERT INTO weblog (email, access_time) VALUES ('$email', '$access_time')";
        $conn->query($sql_insert);
    }
}

// Create logs table if it doesn't exist
$sql_check_logs_table = "SHOW TABLES LIKE 'logs'";
$result_logs_check = $conn->query($sql_check_logs_table);
if ($result_logs_check && $result_logs_check->num_rows == 0) {
    // Table doesn't exist, create it
    $sql_create_logs = "CREATE TABLE logs (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        status VARCHAR(50) NOT NULL,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    $conn->query($sql_create_logs);
    
    // Insert some sample data
    $sample_statuses = ['login_success', 'login_failed', 'door_opened', 'access_granted', 'access_denied'];
    foreach ($sample_statuses as $status) {
        // Random time within the last 24 hours
        $hours = rand(0, 23);
        $minutes = rand(0, 59);
        $seconds = rand(0, 59);
        $time_offset = $hours * 3600 + $minutes * 60 + $seconds;
        $log_time = date('Y-m-d H:i:s', time() - $time_offset);
        
        $sql_insert = "INSERT INTO logs (status, date) VALUES ('$status', '$log_time')";
        $conn->query($sql_insert);
    }
}

// Count users logged in (using sign_up table with 'approved' status)
$sql_users = "SELECT COUNT(*) as total FROM sign_up WHERE status = 'approved'";
$result_users = $conn->query($sql_users);
$users_count = 0;
if ($result_users && $result_users->num_rows > 0) {
  $users_count = $result_users->fetch_assoc()['total'];
}

// Count pending users
$sql_pending = "SELECT COUNT(*) as total FROM sign_up WHERE status = 'pending'";
$result_pending = $conn->query($sql_pending);
$pending_count = 0;
if ($result_pending && $result_pending->num_rows > 0) {
  $pending_count = $result_pending->fetch_assoc()['total'];
}

// Count deleted/rejected users
$sql_deleted = "SELECT COUNT(*) as total FROM sign_up WHERE status = 'rejected'";
$result_deleted = $conn->query($sql_deleted);
$deleted_count = 0;
if ($result_deleted && $result_deleted->num_rows > 0) {
  $deleted_count = $result_deleted->fetch_assoc()['total'];
}

// Check if weblog table exists
$sql_check_weblog = "SHOW TABLES LIKE 'weblog'";
$result_weblog_check = $conn->query($sql_check_weblog);
$has_weblog = false;
if ($result_weblog_check && $result_weblog_check->num_rows > 0) {
  $has_weblog = true;
}

// Check if logs table exists
$sql_check_logs_table = "SHOW TABLES LIKE 'logs'";
$result_logs_check = $conn->query($sql_check_logs_table);
$has_logs_table = false;
if ($result_logs_check && $result_logs_check->num_rows > 0) {
  $has_logs_table = true;
}

// Get recent web logins from weblog table
$weblog_entries = [];
if ($has_weblog) {
  $sql_weblog = "SELECT id, email, access_time FROM weblog ORDER BY access_time DESC LIMIT 10";
  $result_weblog = $conn->query($sql_weblog);
  if ($result_weblog && $result_weblog->num_rows > 0) {
    while ($row = $result_weblog->fetch_assoc()) {
      $row['type'] = 'login';
      $weblog_entries[] = $row;
    }
  }
}

// Get recent logs from logs table
$log_entries = [];
if ($has_logs_table) {
  $sql_logs = "SELECT id, status, date FROM logs ORDER BY date DESC LIMIT 20";
  $result_logs = $conn->query($sql_logs);
  if ($result_logs && $result_logs->num_rows > 0) {
    while ($row = $result_logs->fetch_assoc()) {
      $row['type'] = 'system';
      $log_entries[] = $row;
    }
  }
}

// Get user registrations from sign_up table
$signup_entries = [];
$sql_signup = "SELECT id, email, status, created_at FROM sign_up ORDER BY created_at DESC LIMIT 10";
$result_signup = $conn->query($sql_signup);
if ($result_signup && $result_signup->num_rows > 0) {
  while ($row = $result_signup->fetch_assoc()) {
    $row['type'] = 'signup';
    $row['date'] = $row['created_at']; // Add date key for consistent sorting
    $signup_entries[] = $row;
  }
}

// Combine and sort all entries by date/time
$all_entries = array_merge($weblog_entries, $log_entries, $signup_entries);
usort($all_entries, function($a, $b) {
  $time_a = isset($a['access_time']) ? strtotime($a['access_time']) : strtotime($a['date']);
  $time_b = isset($b['access_time']) ? strtotime($b['access_time']) : strtotime($b['date']);
  return $time_b - $time_a; // Descending order (newest first)
});

// Limit to most recent entries
$recent_entries = array_slice($all_entries, 0, 15);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="../cs/style.css" />
  <script>
    // Prevent browser back button after logout
    // Execute immediately, don't wait for load event
    (function() {
      // Disable browser back button
      window.history.pushState(null, "", window.location.href);
      window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
      };
      
      // If back button is attempted, revalidate session immediately
      window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
          // Page was loaded from cache (back button)
          window.location.reload(); // Force reload from server
        }
      });
    })();
  </script>
</head>
<body>
  <div class="container">
    <?php include 'nav.php'; ?>

    <main class="main-content">
      <?php include 'header.php'; ?>

      <section class="cards">
        <div class="card purple">
          <i class="fa fa-user"></i>
          <div>
            <h2><?php echo $users_count; ?></h2>
            <p>Users Login</p>
          </div>
        </div>
        <div class="card pink">
          <i class="fa fa-clock"></i>
          <div>
            <h2><?php echo $pending_count; ?></h2>
            <p>Pendings</p>
          </div>
        </div>
        <div class="card red">
          <i class="fa fa-trash-alt"></i>
          <div>
            <h2><?php echo $deleted_count; ?></h2>
            <p>Deleted</p>
          </div>
        </div>
      </section>

      <section class="table-section">
        <div class="table-header">
          <h3>Recent Activity</h3>
          <div class="search-container">
            <span class="search-icon-wrapper">
              <i class="fas fa-search"></i>
            </span>
            <input type="text" id="tableSearch" placeholder="Search in logs...">
            <span class="clear-search" id="clearSearch" style="display:none;">Clear</span>
          </div>
        </div>
        
        <div class="filter-buttons">
          <button class="filter-btn active" data-filter="all">All</button>
          <button class="filter-btn" data-filter="login">Web Login</button>
          <button class="filter-btn" data-filter="system">System Log</button>
          <button class="filter-btn" data-filter="signup">Registration</button>
          <button class="filter-btn" data-filter="approved">Approved/Success</button>
          <button class="filter-btn" data-filter="rejected">Rejected/Failed</button>
          <button class="filter-btn" data-filter="pending">Pending</button>
        </div>
        
        <div class="table-scroll-wrapper">
          <div class="table-container">
            <table id="activityTable">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>DATE & TIME</th>
                  <th>TYPE</th>
                  <th>DETAILS</th>
                </tr>
              </thead>
              <tbody>
                <?php if (count($recent_entries) > 0): ?>
                  <?php foreach($recent_entries as $entry): ?>
                    <tr data-type="<?php echo $entry['type']; ?>">
                      <td><?php echo $entry['id']; ?></td>
                      <td>
                        <?php if (isset($entry['access_time'])): ?>
                          <?php 
                            $datetime = new DateTime($entry['access_time']);
                            echo $datetime->format('Y-m-d H:i:s');
                          ?>
                        <?php else: ?>
                          <?php 
                            $datetime = new DateTime($entry['date']);
                            echo $datetime->format('Y-m-d H:i:s');
                          ?>
                        <?php endif; ?>
                      </td>
                      <td>
                        <span class="status-badge <?php echo $entry['type']; ?>">
                          <?php 
                          if ($entry['type'] === 'login') {
                            echo 'Web Login';
                          } elseif ($entry['type'] === 'system') {
                            echo 'System Log';
                          } elseif ($entry['type'] === 'signup') {
                            echo 'User Registration';
                          }
                          ?>
                        </span>
                      </td>
                      <td>
                        <?php if ($entry['type'] === 'login'): ?>
                          <?php echo htmlspecialchars($entry['email']); ?>
                        <?php elseif ($entry['type'] === 'signup'): ?>
                          <?php 
                            echo htmlspecialchars($entry['email']) . ' - ';
                            $status = $entry['status'];
                            $status_class = '';
                            
                            if ($status === 'approved') {
                              $status_class = 'approved';
                            } elseif ($status === 'rejected') {
                              $status_class = 'rejected';
                            } else {
                              $status_class = 'pending';
                            }
                          ?>
                          <span class="status-text <?php echo $status_class; ?>"><?php echo ucfirst($status); ?></span>
                        <?php else: ?>
                          <?php 
                            $status = $entry['status'];
                            $status_class = '';
                            $status_text = htmlspecialchars($status);
                            
                            // Format the status text for better readability
                            $status_text = str_replace('_', ' ', $status_text);
                            $status_text = ucwords($status_text);
                            
                            if (strpos($status, 'success') !== false || strpos($status, 'granted') !== false || strpos($status, 'opened') !== false) {
                              $status_class = 'approved';
                            } else if (strpos($status, 'failed') !== false || strpos($status, 'denied') !== false) {
                              $status_class = 'rejected';
                            } else {
                              $status_class = 'pending';
                            }
                          ?>
                          <span class="status-text <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr id="noDataRow">
                    <td colspan="4">No recent activity data available...</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          
          <div id="noResults" class="no-results">
            No matching records found. <span class="clear-search" onclick="clearSearch()">Clear</span>
          </div>
        </div>
      </section>
    </main>
  </div>

  <script>
  // Set active link in navbar
  document.addEventListener('DOMContentLoaded', function() {
    const currentPage = 'index.php';
    const menuLinks = document.querySelectorAll('.menu a');
    
    menuLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href === currentPage) {
        link.classList.add('active');
      }
    });

    // Auto scroll to middle of table on load
    const tableContainer = document.querySelector('.table-container');
    if (tableContainer && tableContainer.scrollHeight > tableContainer.clientHeight) {
      // Only auto-scroll if there's enough content to scroll
      tableContainer.scrollTop = (tableContainer.scrollHeight - tableContainer.clientHeight) / 2;
    }

    // Real-time search functionality
    const searchInput = document.getElementById('tableSearch');
    const clearSearchBtn = document.getElementById('clearSearch');
    const table = document.getElementById('activityTable');
    const noResults = document.getElementById('noResults');
    const noDataRow = document.getElementById('noDataRow');
    let currentFilter = 'all';
    
    // Hide no results message initially
    noResults.style.display = 'none';
    
    // Search as you type function
    function filterTable() {
      const searchText = searchInput.value.toLowerCase();
      const rows = table.getElementsByTagName('tr');
      let matchFound = false;
      
      // Show/hide clear button
      clearSearchBtn.style.display = searchText ? 'inline' : 'none';
      
      // Skip the header row (index 0)
      for (let i = 1; i < rows.length; i++) {
        if (rows[i].id === 'noDataRow') continue;
        
        const rowText = rows[i].textContent.toLowerCase();
        const rowType = rows[i].getAttribute('data-type');
        const statusElement = rows[i].querySelector('.status-text');
        const statusClass = statusElement ? statusElement.classList[1] : '';
        
        // Check if row matches both the search text and the filter
        const matchesSearch = searchText === '' || rowText.indexOf(searchText) > -1;
        let matchesFilter = false;
        
        if (currentFilter === 'all') {
          matchesFilter = true;
        } else if (currentFilter === 'login' || currentFilter === 'system' || currentFilter === 'signup') {
          matchesFilter = rowType === currentFilter;
        } else if (currentFilter === 'approved' || currentFilter === 'rejected' || currentFilter === 'pending') {
          matchesFilter = statusClass === currentFilter;
        }
        
        if (matchesSearch && matchesFilter) {
          rows[i].style.display = '';
          matchFound = true;
        } else {
          rows[i].style.display = 'none';
        }
      }
      
      // Show/hide no results message
      if (!matchFound) {
        noResults.style.display = 'block';
        if (noDataRow) noDataRow.style.display = 'none';
      } else {
        noResults.style.display = 'none';
        if (noDataRow && !searchText && currentFilter === 'all') noDataRow.style.display = '';
      }
    }
    
    // Add input event listener
    searchInput.addEventListener('input', filterTable);
    
    // Clear search function
    window.clearSearch = function() {
      searchInput.value = '';
      filterTable();
      searchInput.focus();
    };
    
    // Add click event to clear search button
    clearSearchBtn.addEventListener('click', clearSearch);
    
    // Type filter buttons
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(button => {
      button.addEventListener('click', function() {
        // Remove active class from all buttons
        filterButtons.forEach(btn => btn.classList.remove('active'));
        // Add active class to clicked button
        this.classList.add('active');
        
        // Update current filter
        currentFilter = this.getAttribute('data-filter');
        
        // Apply filter
        filterTable();
      });
    });
  });
  </script>
</body>
</html>