<?php
// forgotpass.php
include('conn.php'); // Database connection
session_start(); // Start session for OTP verification

// If user is already logged in, redirect to index.php
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Function to generate random OTP
function generateOTP($length = 6) {
    return substr(str_shuffle("0123456789"), 0, $length);
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    
    // Sanitize input
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    
    // Check if user exists and is approved
    $stmt = $conn->prepare("SELECT * FROM sign_up WHERE email = ? AND status = 'approved'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // User exists and is approved
        $user = $result->fetch_assoc();
        
        // Generate OTP
        $otp = generateOTP();
        $otp_expiry = date('Y-m-d H:i:s', strtotime('+10 minutes')); // OTP valid for 10 minutes
        
        // Store OTP in session
        $_SESSION['otp_data'] = [
            'email' => $email,
            'otp' => $otp,
            'expiry' => $otp_expiry
        ];
        
        // Include PHPMailer
        require_once 'email_sender.php'; // Make sure you save the previous code as email_sender.php

        $to = $email;
        $subject = "Password Reset Verification Code";
        
        // Format the email with HTML
        $message = "
        <html>
        <head>
        <title>Password Reset Verification Code</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
            .header { background-color: #4CAF50; color: white; padding: 10px; text-align: center; border-radius: 5px 5px 0 0; }
            .content { padding: 20px; }
            .otp { font-size: 24px; font-weight: bold; text-align: center; margin: 20px 0; letter-spacing: 5px; }
            .footer { font-size: 12px; color: #777; margin-top: 20px; text-align: center; }
        </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>Password Reset Verification</h2>
                </div>
                <div class='content'>
                    <p>Hello,</p>
                    <p>You have requested to reset your password. Please use the following verification code to complete the process:</p>
                    <div class='otp'>$otp</div>
                    <p>This code will expire in 10 minutes.</p>
                    <p>If you did not request this change, please ignore this email or contact support if you have concerns.</p>
                </div>
                <div class='footer'>
                    <p>This is an automated message, please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Send the email using PHPMailer
        if(sendEmail($to, $subject, $message)) {
            // Redirect to OTP verification page
            header("Location: otppage.php?email=" . urlencode($email));
            exit;
        } else {
            // Email sending failed
            header("Location: forgotpass.php?message=" . urlencode("Failed to send verification code. Please try again."));
            exit;
        }
    } else {
        // No approved account found
        header("Location: forgotpass.php?message=" . urlencode("No approved account found with this email."));
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Forgot Password</title>
  <link rel="stylesheet" href="../cs/forgot.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
  <div class="main-container">
    <!-- Left Panel -->
    <div class="left-panel">
      <div class="left-panel-content">
        <div class="content-top">
          <h1>Email Verification</h1>
          <p>
            You forgot? Please enter the email address<br />
            you want to reset.
          </p>
        </div>
        <div class="image-container">
          <img src="../pictures/3.png" alt="Forgot Password Illustration" class="login-image" />
        </div>
      </div>
    </div>

    <!-- Right Panel -->
    <div class="right-panel">
      <form class="login-form" id="forgot-form" method="POST" action="forgotpass.php">
        <h2>Forgot Password</h2>
        <div class="form-body">
          <label for="forgot-email">E-mail</label>
          <input type="email" id="forgot-email" name="email" placeholder="Enter your registered email" required />

          <button type="submit" class="submit-btn">Send Verification Code</button>
        </div>
      </form>

      <div class="already-account">
        <a href="signlog.php">Back to Login</a>
      </div>
    </div>
  </div>

  <!-- Notification Message -->
  <div id="message-notification" class="hidden">
    <p id="message-text"></p>
    <span id="close-message" class="close-btn">&times;</span>
  </div>

  <script>
    // Show success or error notification
    function showMessage(message, isError = false) {
      const notification = document.getElementById('message-notification');
      const messageText = document.getElementById('message-text');
      const closeButton = document.getElementById('close-message');

      messageText.innerText = message;
      notification.style.backgroundColor = isError ? '#f44336' : '#4CAF50'; // Red for error, green for success
      notification.classList.remove('hidden');
      notification.classList.add('visible');

      // Close button functionality
      closeButton.onclick = function() {
        notification.classList.add('hidden');
      };

      // Optional: Automatically hide after 5 seconds
      setTimeout(function() {
        notification.classList.add('hidden');
      }, 5000);
    }

    // Check URL message and show it on page load
    window.onload = function() {
      const urlParams = new URLSearchParams(window.location.search);
      const message = urlParams.get('message');
      if (message) {
        showMessage(decodeURIComponent(message), 
          message.includes("No approved") || 
          message.includes("Failed to send") || 
          message.includes("error"));
      }
    };
  </script>
</body>
</html>