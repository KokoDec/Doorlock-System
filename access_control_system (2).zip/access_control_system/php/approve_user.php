<?php
include('conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id']) && isset($_POST['status'])) {
    $id = intval($_POST['user_id']);
    $status = $_POST['status']; // approved or any other status you want

    // Update the status of the user
    $stmt = $conn->prepare("UPDATE sign_up SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>
