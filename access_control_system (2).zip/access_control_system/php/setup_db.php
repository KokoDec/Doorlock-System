<?php
// Database connection parameters
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "access_logs";

// Create connection
$conn = new mysqli($host, $user, $pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$sqlCreateDb = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sqlCreateDb)) {
    echo "Database created or already exists<br>";
} else {
    echo "Error creating database: " . $conn->error . "<br>";
}

// Select the database
$conn->select_db($dbname);

// Create logs table if it doesn't exist
$sqlCreateTable = "CREATE TABLE IF NOT EXISTS logs (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    status VARCHAR(50) NOT NULL,
    date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sqlCreateTable)) {
    echo "Table 'logs' created or already exists<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// Check if the logs table is empty
$sqlCheckEmpty = "SELECT COUNT(*) as count FROM logs";
$result = $conn->query($sqlCheckEmpty);
$row = $result->fetch_assoc();

// If the table is empty, populate it with some dummy data
if ($row['count'] == 0) {
    echo "Adding dummy data to logs table...<br>";
    
    // Insert dummy records
    for ($i = 1; $i <= 20; $i++) {
        $status = ($i % 3 == 0) ? 'rejected' : (($i % 2 == 0) ? 'access_granted' : 'pending');
        $date = date('Y-m-d H:i:s', strtotime("-$i hours"));
        
        $sqlInsert = "INSERT INTO logs (status, date) VALUES ('$status', '$date')";
        if ($conn->query($sqlInsert)) {
            echo "Record $i added<br>";
        } else {
            echo "Error adding record $i: " . $conn->error . "<br>";
        }
    }
}

echo "<p>Database setup complete! <a href='controll.php'>Go to Control Panel</a></p>";

$conn->close();
?> 