<?php
/**
 * Header include file
 * This file contains the top navigation bar that can be included in all pages
 */
?>
<link rel="stylesheet" href="../cs/nav.css" />
<header class="topbar">
  <div class="user">
    <img src="../images/welcome.png" alt="User" class="avatar">
  </div>
</header>