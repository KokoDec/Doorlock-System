<?php
// This script handles restoring rejected users back to pending status
include('conn.php');
include('log_entry.php');

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.1 405 Method Not Allowed');
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get input from either FormData or URL-encoded form data
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
$status = $_POST['status'] ?? '';
$email = $_POST['email'] ?? 'Unknown user';

// Validate inputs
if (!$user_id || !$status) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit;
}

// Validate status
if ($status !== 'pending') {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['success' => false, 'message' => 'Invalid status']);
    exit;
}

// Update user status back to pending
$stmt = $conn->prepare("UPDATE sign_up SET status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $user_id);

if ($stmt->execute()) {
    // Log the action
    $action = "Restored user to pending";
    $details = "User ID: $user_id, Email: $email";
    log_action($action, null, $details);
    
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>