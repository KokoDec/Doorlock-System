<?php
// Include the connection file
include('conn.php');

// Debug: Check the contents of $_POST

// Retrieve OTP and email from the POST request
$email = $_POST['email'];  // Corrected to lowercase 'email'
$otp = $_POST['otp'];

// Check if the OTP entered is correct
$sql_check = "SELECT * FROM sign_up WHERE email = ? AND otp = ? AND otp_status = 'pending'";
$stmt_check = $conn->prepare($sql_check);

if ($stmt_check === false) {
    die('Error preparing query: ' . $conn->error);
}

$stmt_check->bind_param('ss', $email, $otp);
$stmt_check->execute();
$result = $stmt_check->get_result();

if ($result->num_rows > 0) {
    // OTP is correct, update the status in sign_up table
    $sql_update = "UPDATE sign_up SET otp_status = 'verified', status = 'pending' WHERE email = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param('s', $email);
    
    if ($stmt_update->execute()) {
        echo "OTP_verified"; // OTP verified successfully
    } else {
        echo "Error updating status.";
    }

    $stmt_update->close();
} else {
    echo "Invalid OTP.";
}

$stmt_check->close();
$conn->close();
?>
