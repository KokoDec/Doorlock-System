<?php
// Start session and check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: signlog.php");
    exit;
}

// Set cache control headers to prevent browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

include('conn.php');

$sql = "SELECT id, email, DATE(created_at) as log_date, TIME(created_at) as log_time, status FROM sign_up WHERE status = 'pending' ORDER BY created_at DESC LIMIT 50";

$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Logs Dashboard</title>
  <link rel="stylesheet" href="../cs/logs.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    .password-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.8);
      backdrop-filter: blur(8px);
      z-index: 9999;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    
    .password-modal {
      background: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
      width: 350px;
      max-width: 90%;
      text-align: center;
    }
    
    .password-modal h2 {
      margin-top: 0;
      color: #333;
    }
    
    .password-input {
      width: 200px;
      margin: 20px auto;
      display: flex;
      justify-content: space-between;
    }
    
    .digit-input {
      width: 30px;
      height: 40px;
      font-size: 20px;
      text-align: center;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    
    .submit-btn {
      background: #4caf50;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      transition: background 0.3s;
      margin-right: 10px;
    }
    
    .submit-btn:hover {
      background: #388e3c;
    }
    
    .back-btn {
      background: #f44336;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      transition: background 0.3s;
      text-decoration: none;
    }
    
    .back-btn:hover {
      background: #d32f2f;
    }
    
    .btn-group {
      margin-top: 20px;
    }
    
    .error-message {
      color: #f44336;
      margin-top: 10px;
      display: none;
    }
    
    .main-content-protected {
      filter: blur(10px);
      pointer-events: none;
      user-select: none;
    }
  </style>
  <script>
    // Prevent browser back button after logout
    // Execute immediately, don't wait for load event
    (function() {
      // Disable browser back button
      window.history.pushState(null, "", window.location.href);
      window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
      };
      
      // If back button is attempted, revalidate session immediately
      window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
          // Page was loaded from cache (back button)
          window.location.reload(); // Force reload from server
        }
      });
    })();
  </script>
</head>
<body>
    <!-- Password Protection Overlay -->
    <div id="passwordOverlay" class="password-overlay">
      <div class="password-modal">
        <h2>Access Protected</h2>
        <p>Please enter the 6-digit security code to access logs</p>
        <div class="password-input">
          <input type="password" maxlength="1" class="digit-input" id="digit1" data-next="digit2">
          <input type="password" maxlength="1" class="digit-input" id="digit2" data-next="digit3" data-prev="digit1">
          <input type="password" maxlength="1" class="digit-input" id="digit3" data-next="digit4" data-prev="digit2">
          <input type="password" maxlength="1" class="digit-input" id="digit4" data-next="digit5" data-prev="digit3">
          <input type="password" maxlength="1" class="digit-input" id="digit5" data-next="digit6" data-prev="digit4">
          <input type="password" maxlength="1" class="digit-input" id="digit6" data-prev="digit5">
        </div>
        <div class="btn-group">
          <button class="submit-btn" id="submitCode">Submit</button>
          <a href="index.php" class="back-btn">Dashboard</a>
        </div>
        <p class="error-message" id="errorMessage">Incorrect code. Please try again.</p>
      </div>
    </div>

    <div class="container">
        <?php include 'nav.php'; ?>
        
        <main class="main-content" id="mainContent">
      <section class="content">
        <div class="content-header">
          <h2><?= $result->num_rows ?> Logs</h2>
          <div class="search-container">
            <input type="text" id="searchInput" class="search-filter" placeholder="Search logs...">
            <i class="fas fa-search search-icon"></i>
          </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>ID</th>
              <th>Email</th>
              <th>Date</th>
              <th>Time</th>
              <th>Status</th>
              <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
              <tr data-id="<?= $row['id'] ?>">
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= $row['log_date'] ?></td>
                <td><?= $row['log_time'] ?></td>
                <td><?= ucfirst(htmlspecialchars($row['status'])) ?></td>
                <td class="actions">
                  <?php if ($row['status'] !== 'approved'): ?>
                    <button class="approve-btn" data-id="<?= $row['id'] ?>">
                      <i class="fas fa-check"></i> Approve
                    </button>
                  <?php endif; ?>
                  <button class="reject-btn" data-id="<?= $row['id'] ?>">
                    <i class="fas fa-times"></i> Reject
                  </button>
                  <button class="delete-btn" data-id="<?= $row['id'] ?>">
                    <i class="fas fa-trash"></i> Delete
                  </button>
                </td>
              </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
      </section>
        </main>
    </div>

  <!-- Delete Confirmation Modal -->
  <div id="confirmModal" class="modal" aria-hidden="true">
    <div class="modal-content">
      <p>Are you sure you want to delete this account?</p>
      <div class="modal-actions">
        <button id="confirmDelete" style="background-color: #e74c3c; color: white;">Delete</button>
        <button id="cancelBtn" style="background-color: #f1f1f1; color: #333;">Cancel</button>
      </div>
    </div>
  </div>

  <!-- Approve Confirmation Modal -->
  <div id="approveModal" class="modal" aria-hidden="true">
    <div class="modal-content">
      <p>Are you sure you want to approve this account?</p>
      <div class="modal-actions">
        <button id="confirmApprove" style="background-color: #28a745; color: white;">Approve</button>
        <button id="cancelApprove" style="background-color: #f1f1f1; color: #333;">Cancel</button>
      </div>
    </div>
  </div>

  <!-- Reject Confirmation Modal -->
  <div id="rejectModal" class="modal" aria-hidden="true">
    <div class="modal-content">
      <p>Are you sure you want to reject this account?</p>
      <div class="modal-actions">
        <button id="confirmReject" style="background-color: #ff9800; color: white;">Reject</button>
        <button id="cancelReject" style="background-color: #f1f1f1; color: #333;">Cancel</button>
      </div>
    </div>
  </div>

  <!-- Toast Messages -->
  <div id="approvalToast" class="toast">Account approved! Click anywhere to dismiss.</div>
  <div id="rejectToast" class="toast">Account rejected and moved to trash bin! Click anywhere to dismiss.</div>
  <div id="deleteToast" class="toast">Account deleted! Click anywhere to dismiss.</div>
    
    <script>
    // Wait for DOM to be fully loaded
    window.onload = function() {
      const confirmModal = document.getElementById('confirmModal');
      const approveModal = document.getElementById('approveModal');
      const rejectModal = document.getElementById('rejectModal');
      const approvalToast = document.getElementById('approvalToast');
      const rejectToast = document.getElementById('rejectToast');
      const deleteToast = document.getElementById('deleteToast');
      const searchInput = document.getElementById('searchInput');
      const passwordOverlay = document.getElementById('passwordOverlay');
      const mainContent = document.getElementById('mainContent');
      const errorMessage = document.getElementById('errorMessage');
      const correctCode = "222253";
      
      // Apply protected class
      mainContent.classList.add('main-content-protected');
      
      // Set focus on first digit input
      document.getElementById('digit1').focus();
      
      // Handle digit input navigation
      document.querySelectorAll('.digit-input').forEach(input => {
        input.addEventListener('keyup', function(e) {
          // If a digit is entered, move to next input
          if (this.value.length === 1) {
            const nextInput = this.dataset.next;
            if (nextInput) {
              document.getElementById(nextInput).focus();
            }
          }
          
          // If backspace is pressed, clear current and move to previous input
          if (e.key === 'Backspace') {
            const prevInput = this.dataset.prev;
            if (prevInput) {
              document.getElementById(prevInput).focus();
            }
          }
        });
        
        // Prevent non-numeric input
        input.addEventListener('input', function() {
          this.value = this.value.replace(/[^0-9]/g, '');
        });
      });
      
      // Handle code submission
      document.getElementById('submitCode').addEventListener('click', function() {
        let enteredCode = '';
        document.querySelectorAll('.digit-input').forEach(input => {
          enteredCode += input.value;
        });
        
        if (enteredCode === correctCode) {
          passwordOverlay.style.display = 'none';
          mainContent.classList.remove('main-content-protected');
        } else {
          errorMessage.style.display = 'block';
          document.querySelectorAll('.digit-input').forEach(input => {
            input.value = '';
          });
          document.getElementById('digit1').focus();
          
          // Hide error message after 3 seconds
          setTimeout(() => {
            errorMessage.style.display = 'none';
          }, 3000);
        }
      });
      
      console.log('Modal elements:', {
        confirmModal,
        approveModal,
        rejectModal
      });

      let approveUserId = null;
      let rejectUserId = null;
      let deleteUserId = null;
      
      // Debug function to check for JavaScript errors
      function debugEvent(event) {
        console.log('Event fired:', event.type, 'on element:', event.target);
      }
      
      // Function to show modal
      function showModal(modal) {
        // Add show class
        modal.classList.add('show');
      }
      
      // Function to hide modal
      function hideModal(modal) {
        modal.classList.remove('show');
      }
      
      // Function to show toast
      function showToast(toast) {
        toast.classList.add('show');
        
        // Set timeout to auto-hide after 4 seconds
        const timeoutId = setTimeout(() => {
          toast.classList.remove('show');
        }, 4000);
        
        // Allow dismissing by clicking on the toast
        toast.addEventListener('click', function() {
          clearTimeout(timeoutId);
          toast.classList.remove('show');
        });
        
        // Allow dismissing by clicking anywhere on the document
        const dismissHandler = function() {
          clearTimeout(timeoutId);
          toast.classList.remove('show');
          document.removeEventListener('click', dismissHandler);
        };
        
        // Add a small delay before adding the document click handler
        // to prevent immediate dismissal
        setTimeout(() => {
          document.addEventListener('click', dismissHandler);
        }, 100);
      }
      
      // Search filter functionality
      searchInput.addEventListener('input', function() {
        const searchValue = this.value.toLowerCase();
        document.querySelectorAll('tbody tr').forEach(row => {
          const rowText = Array.from(row.querySelectorAll('td')).map(cell => cell.textContent.toLowerCase()).join(' ');
          row.style.display = rowText.includes(searchValue) ? '' : 'none';
        });
      });

      try {
        // Log all buttons
        console.log('Approve buttons:', document.querySelectorAll('.approve-btn').length);
        console.log('Reject buttons:', document.querySelectorAll('.reject-btn').length);
        console.log('Delete buttons:', document.querySelectorAll('.delete-btn').length);
        
        // Direct click handler for testing
        document.querySelectorAll('.approve-btn').forEach(btn => {
          console.log('Adding click event to approve button:', btn);
          btn.onclick = function(e) {
            console.log('Approve button clicked via onclick!', this.dataset.id);
            approveUserId = this.dataset.id;
            showModal(approveModal);
            e.preventDefault();
            return false;
          };
        });

        // Open delete modal
        document.querySelectorAll('.delete-btn').forEach(btn => {
          btn.addEventListener('click', function(e) {
            debugEvent(e);
            deleteUserId = this.dataset.id;
            showModal(confirmModal);
          });
        });

        // Cancel delete
        document.getElementById('cancelBtn').addEventListener('click', function(e) {
          debugEvent(e);
          hideModal(confirmModal);
          deleteUserId = null;
        });

        // Open reject modal
        document.querySelectorAll('.reject-btn').forEach(btn => {
          btn.addEventListener('click', function(e) {
            debugEvent(e);
            rejectUserId = this.dataset.id;
            showModal(rejectModal);
          });
        });

        // Cancel reject
        document.getElementById('cancelReject').addEventListener('click', function(e) {
          debugEvent(e);
          hideModal(rejectModal);
          rejectUserId = null;
        });
        
        // Cancel approve
        document.getElementById('cancelApprove').addEventListener('click', function(e) {
          debugEvent(e);
          hideModal(approveModal);
          approveUserId = null;
        });
      } catch (error) {
        console.error('Error in event listeners setup:', error);
      }

      // Confirm approve
      document.getElementById('confirmApprove').addEventListener('click', function() {
        if (!approveUserId) return;

        fetch('approve_user.php', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: `user_id=${approveUserId}&status=approved`
        })
        .then(res => {
          console.log('Approve response status:', res.status);
          return res.json().catch(err => {
            console.error('JSON parse error:', err);
            return { success: false, message: 'Invalid response format' };
          });
        })
        .then(data => {
          console.log('Approve response data:', data);
          if (data.success) {
            const row = document.querySelector(`tr[data-id="${approveUserId}"]`);
            row.remove();
            showToast(approvalToast);
          } else {
            alert(data.message || 'Error approving user.');
          }
          hideModal(approveModal);
          approveUserId = null;
        })
        .catch((error) => {
          console.error('Fetch error:', error);
          alert('Failed to connect to server.');
          hideModal(approveModal);
        });
      });

      // Confirm reject
      document.getElementById('confirmReject').addEventListener('click', function() {
        if (!rejectUserId) return;

        fetch('reject_user.php', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: `user_id=${rejectUserId}&status=rejected`
        })
        .then(res => {
          console.log('Reject response status:', res.status);
          return res.json().catch(err => {
            console.error('JSON parse error:', err);
            return { success: false, message: 'Invalid response format' };
          });
        })
        .then(data => {
          console.log('Reject response data:', data);
          if (data.success) {
            const row = document.querySelector(`tr[data-id="${rejectUserId}"]`);
            row.remove();
            showToast(rejectToast);
          } else {
            alert(data.message || 'Error rejecting user.');
          }
          hideModal(rejectModal);
          rejectUserId = null;
        })
        .catch((error) => {
          console.error('Fetch error:', error);
          alert('Failed to connect to server.');
          hideModal(rejectModal);
        });
      });

      // Confirm delete
      document.getElementById('confirmDelete').addEventListener('click', function() {
        if (!deleteUserId) return;

        fetch('delete_user.php', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: `user_id=${deleteUserId}`
        })
        .then(response => {
          console.log('Delete response status:', response.status);
          return response.json().catch(err => {
            console.error('JSON parse error:', err);
            // Continue with UI update even if JSON parse fails
            return { success: true };
          });
        })
        .then(data => {
          console.log('Delete response data:', data);
          // Handle the redirect from delete_user.php
          const row = document.querySelector(`tr[data-id="${deleteUserId}"]`);
          row.remove();
          showToast(deleteToast);
          hideModal(confirmModal);
          deleteUserId = null;
        })
        .catch((error) => {
          console.error('Fetch error:', error);
          alert('Failed to connect to server.');
          hideModal(confirmModal);
        });
      });
    };
    </script>
</body>
</html>