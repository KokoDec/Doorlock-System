<?php
// This script handles the rejection of users from the logs page
include('conn.php');

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.1 405 Method Not Allowed');
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Validate inputs
if (!isset($_POST['user_id']) || !isset($_POST['status'])) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit;
}

$user_id = intval($_POST['user_id']);
$status = $_POST['status'];

// Validate status
if ($status !== 'rejected') {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['success' => false, 'message' => 'Invalid status']);
    exit;
}

// Update user status to rejected
$stmt = $conn->prepare("UPDATE sign_up SET status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $user_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>