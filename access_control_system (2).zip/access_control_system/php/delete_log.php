<?php
include('conn.php');

header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if log_id was provided
    if (isset($_POST['log_id']) && is_numeric($_POST['log_id'])) {
        $log_id = intval($_POST['log_id']);
        
        // Delete the log entry
        $sql = "DELETE FROM logs WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $log_id);
        
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                // Successfully deleted
                echo json_encode(['success' => true]);
            } else {
                // Log not found
                echo json_encode(['success' => false, 'message' => 'Log not found']);
            }
        } else {
            // Error executing query
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        }
        
        $stmt->close();
    } else {
        // Invalid log_id
        echo json_encode(['success' => false, 'message' => 'Invalid log ID']);
    }
} else {
    // Not a POST request
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?> 