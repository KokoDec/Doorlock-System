<?php
include('conn.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Modal Test Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
    }
    button {
      padding: 10px 15px;
      margin: 10px;
      cursor: pointer;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
    }
    .modal {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }
    .modal.show {
      display: flex;
    }
    .modal-content {
      background: white;
      padding: 30px;
      border-radius: 10px;
      text-align: center;
      width: 400px;
      max-width: 90%;
    }
    .modal-buttons {
      margin-top: 20px;
    }
    .modal-buttons button {
      margin: 0 10px;
    }
  </style>
</head>
<body>
  <h1>Modal Test Page</h1>
  
  <button id="openApproveModal">Open Approve Modal</button>
  <button id="openRejectModal">Open Reject Modal</button>
  <button id="openDeleteModal">Open Delete Modal</button>
  
  <!-- Approve Modal -->
  <div id="approveModal" class="modal">
    <div class="modal-content">
      <h2>Approve User</h2>
      <p>Are you sure you want to approve this user?</p>
      <div class="modal-buttons">
        <button id="cancelApprove">Cancel</button>
        <button id="confirmApprove">Approve</button>
      </div>
    </div>
  </div>
  
  <!-- Reject Modal -->
  <div id="rejectModal" class="modal">
    <div class="modal-content">
      <h2>Reject User</h2>
      <p>Are you sure you want to reject this user?</p>
      <div class="modal-buttons">
        <button id="cancelReject">Cancel</button>
        <button id="confirmReject">Reject</button>
      </div>
    </div>
  </div>
  
  <!-- Delete Modal -->
  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <h2>Delete User</h2>
      <p>Are you sure you want to delete this user?</p>
      <div class="modal-buttons">
        <button id="cancelDelete">Cancel</button>
        <button id="confirmDelete">Delete</button>
      </div>
    </div>
  </div>
  
  <script>
    // Get modal elements
    const approveModal = document.getElementById('approveModal');
    const rejectModal = document.getElementById('rejectModal');
    const deleteModal = document.getElementById('deleteModal');
    
    // Open modal buttons
    document.getElementById('openApproveModal').addEventListener('click', function() {
      console.log('Opening approve modal');
      approveModal.classList.add('show');
    });
    
    document.getElementById('openRejectModal').addEventListener('click', function() {
      console.log('Opening reject modal');
      rejectModal.classList.add('show');
    });
    
    document.getElementById('openDeleteModal').addEventListener('click', function() {
      console.log('Opening delete modal');
      deleteModal.classList.add('show');
    });
    
    // Cancel buttons
    document.getElementById('cancelApprove').addEventListener('click', function() {
      approveModal.classList.remove('show');
    });
    
    document.getElementById('cancelReject').addEventListener('click', function() {
      rejectModal.classList.remove('show');
    });
    
    document.getElementById('cancelDelete').addEventListener('click', function() {
      deleteModal.classList.remove('show');
    });
    
    // Confirm buttons (just close the modals for testing)
    document.getElementById('confirmApprove').addEventListener('click', function() {
      alert('User approved!');
      approveModal.classList.remove('show');
    });
    
    document.getElementById('confirmReject').addEventListener('click', function() {
      alert('User rejected!');
      rejectModal.classList.remove('show');
    });
    
    document.getElementById('confirmDelete').addEventListener('click', function() {
      alert('User deleted!');
      deleteModal.classList.remove('show');
    });
  </script>
</body>
</html> 