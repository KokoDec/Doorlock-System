<?php
// Start session and check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: signlog.php");
    exit;
}

// Set cache control headers to prevent browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

include('conn.php');

// Query to fetch data from the logs table
$sql = "SELECT id, status, date FROM logs ORDER BY date DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

// If no data in the logs table, let's add some dummy data for display purposes
if ($result->num_rows == 0) {
    // Create dummy data for demonstration
    for ($i = 1; $i <= 20; $i++) {
        $status = ($i % 3 == 0) ? 'rejected' : (($i % 2 == 0) ? 'access_granted' : 'pending');
        $date = date('Y-m-d H:i:s', strtotime("-" . $i . " hours"));
        
        $insertSql = "INSERT INTO logs (status, date) VALUES ('$status', '$date')";
        $conn->query($insertSql);
    }
    
    // Re-run the query to get the newly added data
    $sql = "SELECT id, status, date FROM logs ORDER BY date DESC";
    $result = $conn->query($sql);
}

$totalLogs = $result->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Control Panel</title>
  <link rel="stylesheet" href="../cs/controll.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script>
    // Prevent browser back button after logout
    // Execute immediately, don't wait for load event
    (function() {
      // Disable browser back button
      window.history.pushState(null, "", window.location.href);
      window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
      };
      
      // If back button is attempted, revalidate session immediately
      window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
          // Page was loaded from cache (back button)
          window.location.reload(); // Force reload from server
        }
      });
    })();
  </script>
</head>
<body>
  <div class="container">
    <?php include 'nav.php'; ?>

    <main class="main-content">
      <div class="main-header">
        <h1>Access Control Logs</h1>
      </div>
      
      <div class="table-wrapper">
        <div class="search-section">
          <input type="text" id="searchInput" placeholder="Search logs...">
        </div>

        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>DATE</th>
              <th>TIME</th>
              <th>STATUS</th>
              <th>ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($totalLogs > 0): ?>
              <?php while($row = $result->fetch_assoc()): ?>
                <?php 
                  // Split timestamp into date and time
                  $date = date('Y-m-d', strtotime($row['date']));
                  $time = date('H:i:s', strtotime($row['date']));
                  
                  // Determine status class
                  $statusClass = '';
                  $status = $row['status'];
                  if (strpos($status, 'granted') !== false) {
                    $statusClass = 'status-granted';
                  } else if (strpos($status, 'rejected') !== false || strpos($status, 'denied') !== false) {
                    $statusClass = 'status-denied';
                  } else {
                    $statusClass = 'status-pending';
                  }
                ?>
                <tr data-id="<?= $row['id'] ?>">
                  <td><?= $row['id'] ?></td>
                  <td><?= $date ?></td>
                  <td><?= $time ?></td>
                  <td>
                    <span class="status-badge <?= $statusClass ?>">
                      <?= ucfirst(str_replace('_', ' ', $row['status'])) ?>
                    </span>
                  </td>
                  <td class="actions">
                    <a href="#" class="btn-link btn-view-link" onclick="showViewModal(<?= $row['id'] ?>); return false;">
                      <i class="fas fa-eye"></i> View
                    </a>
                    <a href="#" class="btn-link btn-delete-link" onclick="showDeleteModal(<?= $row['id'] ?>); return false;">
                      <i class="fas fa-trash"></i> Delete
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="5" style="text-align: center; padding: 20px;">No logs found</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>

  <!-- Delete Confirmation Modal -->
  <div id="confirmModal" class="modal">
    <div class="modal-content">
      <h3>Confirm Deletion</h3>
      <p>Are you sure you want to delete this log? This action cannot be undone.</p>
      <div class="modal-actions">
        <button id="confirmDelete" class="modal-button delete-button">Delete</button>
        <button id="cancelBtn" class="modal-button cancel-button">Cancel</button>
      </div>
    </div>
  </div>

  <!-- View Log Modal -->
  <div id="viewModal" class="modal">
    <div class="modal-content" style="max-width: 800px; width: 90%;">
      <h3>Log Details</h3>
      <div id="logDetails" class="details-container" style="max-height: 600px;"></div>
      <div class="modal-actions">
        <button id="closeViewBtn" class="modal-button close-button">Close</button>
      </div>
    </div>
  </div>

  <!-- Toast Messages -->
  <div id="deleteToast" class="toast hidden">
    <i class="fas fa-check-circle"></i> Log deleted successfully!
  </div>

  <style>
    /* Custom styles for log details */
    #viewModal .details-table {
      width: 100%;
      font-size: 16px;
    }
    
    #viewModal .details-table td {
      padding: 15px;
      font-size: 16px;
    }
    
    #viewModal .details-table tr:hover {
      background-color: transparent !important;
    }
    
    /* Align buttons to the left in delete modal */
    #confirmModal .modal-actions {
      justify-content: flex-start;
    }
    
    #confirmModal .modal-actions button:last-child {
      margin-left: auto;
    }
  </style>

  <script>
    // Variables to store modal elements
    const confirmModal = document.getElementById('confirmModal');
    const viewModal = document.getElementById('viewModal');
    const logDetailsContainer = document.getElementById('logDetails');
    let currentLogIdToDelete = null;

    // Function to show the view modal and load log details
    function showViewModal(logId) {
      console.log('Showing view modal for log ID:', logId);
      viewModal.classList.add('show');
      logDetailsContainer.innerHTML = '<div class="loading-spinner"><i class="fas fa-spinner"></i> Loading...</div>';
      
      // Fetch log details
      fetch('view_log.php?id=' + logId)
        .then(response => {
          console.log('Response status:', response.status);
          return response.json();
        })
        .then(data => {
          console.log('Data received:', data);
          
          if (data.success) {
            // Create details table
            let detailsHtml = '<table class="details-table">';
            for (const [key, value] of Object.entries(data.log)) {
              // Format the key for display
              const formattedKey = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
              detailsHtml += `<tr><td>${formattedKey}</td><td>${value}</td></tr>`;
            }
            detailsHtml += '</table>';
            logDetailsContainer.innerHTML = detailsHtml;
          } else {
            logDetailsContainer.innerHTML = '<div class="error-message">'+
              (data.message || 'Error loading log details')+
              '</div>';
          }
        })
        .catch(error => {
          console.error('Error fetching log details:', error);
          logDetailsContainer.innerHTML = '<div class="error-message">'+
            'Failed to load log details. Check console for errors.'+
            '</div>';
        });
    }

    // Function to show the delete confirmation modal
    function showDeleteModal(logId) {
      console.log('Showing delete modal for log ID:', logId);
      currentLogIdToDelete = logId;
      confirmModal.classList.add('show');
    }

    // Close view modal
    document.getElementById('closeViewBtn').addEventListener('click', function() {
      console.log('Closing view modal');
      viewModal.classList.remove('show');
    });

    // Cancel delete
    document.getElementById('cancelBtn').addEventListener('click', function() {
      console.log('Canceling delete');
      confirmModal.classList.remove('show');
      currentLogIdToDelete = null;
    });

    // Confirm delete
    document.getElementById('confirmDelete').addEventListener('click', function() {
      console.log('Confirming delete for log ID:', currentLogIdToDelete);
      
      if (!currentLogIdToDelete) {
        console.error('No log ID set for deletion');
        return;
      }
      
      // Create form data
      const formData = new FormData();
      formData.append('log_id', currentLogIdToDelete);
      
      // Delete the log
      fetch('delete_log.php', {
        method: 'POST',
        body: formData
      })
      .then(response => {
        console.log('Delete response status:', response.status);
        return response.json();
      })
      .then(data => {
        console.log('Delete result:', data);
        
        if (data.success) {
          // Remove the row from the table
          const row = document.querySelector(`tr[data-id="${currentLogIdToDelete}"]`);
          if (row) {
            row.remove();
          }
          
          // Show success message
          const toast = document.getElementById('deleteToast');
          toast.classList.remove('hidden');
          setTimeout(() => {
            toast.classList.add('hidden');
          }, 3000);
        } else {
          alert(data.message || 'Failed to delete log');
        }
        
        // Close the modal
        confirmModal.classList.remove('show');
        currentLogIdToDelete = null;
      })
      .catch(error => {
        console.error('Error deleting log:', error);
        alert('An error occurred while deleting the log');
        confirmModal.classList.remove('show');
      });
    });

    // Search functionality
    document.getElementById('searchInput').addEventListener('keyup', function() {
      const searchText = this.value.toUpperCase();
      const tableRows = document.querySelectorAll('tbody tr');
      
      tableRows.forEach(row => {
        if (row.cells.length === 1) return; // Skip "no logs found" row
        
        let match = false;
        for (let i = 0; i < row.cells.length - 1; i++) { // Skip the actions cell
          const cellText = row.cells[i].textContent || row.cells[i].innerText;
          if (cellText.toUpperCase().indexOf(searchText) > -1) {
            match = true;
            break;
          }
        }
        
        row.style.display = match ? '' : 'none';
      });
    });

    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
      if (event.target === confirmModal) {
        confirmModal.classList.remove('show');
        currentLogIdToDelete = null;
      }
      
      if (event.target === viewModal) {
        viewModal.classList.remove('show');
      }
    });
  </script>
</body>
</html>