<?php
/**
 * Navigation sidebar include file
 * This file contains the sidebar navigation that can be included in all pages
 */

// Get the current page filename
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!-- Navigation Sidebar -->
<style>
    /* Navigation sidebar styles */
    .sidebar {
        width: 240px;
        background: #333;
        color: #fff;
        display: flex;
        flex-direction: column;
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        z-index: 100;
        padding-top: 50px;
    }

    /* Menu styling */
    .menu {
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        padding: 0;
        margin: 30px 0;
    }

    .menu a {
        color: #fff;
        text-decoration: none;
        padding: 18px 24px;
        margin: 18px 15px;
        border-radius: 8px;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        font-size: 16px;
    }

    .menu a i {
        margin-right: 12px;
        width: 20px;
        text-align: center;
    }

    .menu a:hover {
        background-color: rgba(58, 90, 249, 0.2);
    }

    .menu a.active {
        background-color: #3a5af9;
        color: white;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    /* Logout button styling */
    .logout {
        padding: 20px 15px;
        margin-top: auto;
        margin-bottom: 30px;
        border-top: 1px solid #444;
    }

    .logout a {
        color: #fff;
        text-decoration: none;
        display: flex;
        align-items: center;
        padding: 18px 24px;
        border-radius: 8px;
        transition: all 0.3s ease;
    }

    .logout a i {
        margin-right: 12px;
        width: 20px;
        text-align: center;
    }

    .logout a:hover {
        background-color: rgba(255, 59, 48, 0.2);
    }

    /* Modal styling */
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }

    .modal-content {
        background-color: #202124;
        margin: auto;
        padding: 30px;
        border-radius: 10px;
        width: 350px;
        color: white;
        text-align: center;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
    }

    .modal-header {
        margin-bottom: 20px;
    }

    .modal-header h3 {
        font-size: 22px;
        margin: 0;
    }

    .modal-body {
        margin-bottom: 25px;
        font-size: 18px;
    }

    .modal-footer {
        display: flex;
        justify-content: center;
        gap: 20px;
    }

    .btn-primary, .btn-secondary {
        font-size: 16px;
        padding: 12px 30px;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.3s ease;
        min-width: 100px;
    }

    .btn-primary {
        background-color: #3a5af9;
        color: white;
        border: none;
    }

    .btn-primary:hover {
        background-color: #2847e0;
        transform: translateY(-2px);
    }

    .btn-secondary {
        background-color: transparent;
        color: white;
        border: 1px solid #888;
    }

    .btn-secondary:hover {
        background-color: rgba(255, 255, 255, 0.1);
        transform: translateY(-2px);
    }

    /* Adjust main content to account for sidebar */
    .main-content {
        margin-left: 240px;
        width: calc(100% - 240px);
        overflow-x: hidden;
    }
</style>

<aside class="sidebar">
    <nav class="menu">
        <a href="index.php" class="<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>">
            <i class="fa fa-chart-line"></i> Dashboard
        </a>
        <a href="controll.php" class="<?php echo ($current_page == 'controll.php') ? 'active' : ''; ?>">
            <i class="fa fa-sliders-h"></i> Control Panel
        </a>
        <a href="logs.php" class="<?php echo ($current_page == 'logs.php') ? 'active' : ''; ?>">
            <i class="fa fa-file-alt"></i> Logs
        </a>
        <a href="trash-bin.php" class="<?php echo ($current_page == 'trash-bin.php') ? 'active' : ''; ?>">
            <i class="fa fa-trash"></i> Trash Bin
        </a>
    </nav>
    <div class="logout">
        <a href="javascript:void(0)" onclick="showLogoutConfirmation()">
            <i class="fa fa-sign-out-alt"></i> Logout
        </a>
    </div>
</aside>

<div id="logoutModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Confirmation</h3>
        </div>
        <div class="modal-body">
            <p>Are you sure you want to log out?</p>
        </div>
        <div class="modal-footer">
            <button id="okButton" class="btn-primary">OK</button>
            <button id="cancelButton" class="btn-secondary">Cancel</button>
        </div>
    </div>
</div>

<script>
function showLogoutConfirmation() {
    document.getElementById('logoutModal').style.display = 'flex';
}

document.addEventListener('DOMContentLoaded', function() {
    var modal = document.getElementById('logoutModal');
    
    document.getElementById('okButton').addEventListener('click', function() {
        window.location.href = "logout.php";
    });
    
    document.getElementById('cancelButton').addEventListener('click', function() {
        modal.style.display = 'none';
    });
    
    // Close modal when clicking outside the modal content
    window.addEventListener('click', function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });
});
</script>