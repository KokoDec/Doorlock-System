<?php
// Start session to check for user data
session_start();

// If user is already logged in, redirect to index.php
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Get email from URL parameter
$email = isset($_GET['email']) ? $_GET['email'] : '';
$message = isset($_GET['message']) ? $_GET['message'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>OTP Verification</title>
  <link rel="stylesheet" href="../cs/styles.css" />
  <link rel="stylesheet" href="../cs/otp.css" />
  <!-- Font Awesome CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <script>
    // Prevent browser back navigation after logout
    // Execute immediately, don't wait for load event
    (function() {
      // Disable browser back button
      window.history.pushState(null, "", window.location.href);
      window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
      };
      
      // If back button is attempted, revalidate session immediately
      window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
          // Page was loaded from cache (back button)
          window.location.reload(); // Force reload from server
        }
      });
    })();
  </script>
</head>
<body>
  <div class="main-container">
    <!-- Left Panel -->
    <div class="left-panel">
      <div class="left-panel-content">
        <div class="content-top">
          <h1>Verify Your Identity</h1>
          <p>
            We've sent a verification code to your email.<br />
            Enter it below to continue with your password reset.
          </p>
        </div>
        <div class="image-container">
          <img src="../pictures/3.png" alt="Verification Illustration" class="login-image" />
        </div>
      </div>
    </div>

    <!-- Right Panel -->
    <div class="right-panel">
      <form class="login-form" id="otp-form" method="POST" action="verify otppass.php">
        <h2>Enter Verification Code</h2>
        <div class="form-body">
          <p class="verification-text">We've sent a 6-digit code to <span id="user-email" class="user-email-display"><?php echo htmlspecialchars($email); ?></span></p>
          
          <div class="otp-container">
            <input type="text" class="otp-input" name="otp[]" maxlength="1" pattern="[0-9]" inputmode="numeric" required>
            <input type="text" class="otp-input" name="otp[]" maxlength="1" pattern="[0-9]" inputmode="numeric" required>
            <input type="text" class="otp-input" name="otp[]" maxlength="1" pattern="[0-9]" inputmode="numeric" required>
            <input type="text" class="otp-input" name="otp[]" maxlength="1" pattern="[0-9]" inputmode="numeric" required>
            <input type="text" class="otp-input" name="otp[]" maxlength="1" pattern="[0-9]" inputmode="numeric" required>
            <input type="text" class="otp-input" name="otp[]" maxlength="1" pattern="[0-9]" inputmode="numeric" required>
          </div>
          
          <input type="hidden" id="email-field" name="email" value="<?php echo htmlspecialchars($email); ?>">
          
          <div class="resend-container">
            <a class="resend-link" id="resend-otp">Didn't receive the code? Resend</a>
            <span id="countdown" style="display: none; font-size: 14px;"></span>
          </div>

          <button type="submit" class="submit-btn">VERIFY & CONTINUE</button>
        </div>
      </form>

      <div class="already-account">
        <a href="forgotpass.php">Back to Forgot Password</a>
      </div>
    </div>
  </div>

  <!-- Notification Popup -->
  <?php if ($message): ?>
    <div class="popup-overlay" onclick="dismissPopup()">
      <div class="popup-box <?php echo (strpos($message, 'Invalid') !== false || strpos($message, 'expired') !== false) ? 'error' : ''; ?>">
        <p><?php echo $message; ?></p>
      </div>
    </div>
  <?php endif; ?>

  <script>
    // Auto-focus next input in OTP field
    const otpInputs = document.querySelectorAll('.otp-input');
    
    otpInputs.forEach((input, index) => {
      input.addEventListener('input', function() {
        if (this.value.length === this.maxLength) {
          if (index < otpInputs.length - 1) {
            otpInputs[index + 1].focus();
          }
        }
      });
      
      input.addEventListener('keydown', function(e) {
        if (e.key === 'Backspace' && !this.value) {
          if (index > 0) {
            otpInputs[index - 1].focus();
          }
        }
      });
    });
    
    // Focus the first input field when page loads
    window.onload = function() {
      otpInputs[0].focus();
      
      // Check for message parameter and display it
      const urlParams = new URLSearchParams(window.location.search);
      const message = urlParams.get('message');
      
      if (message) {
        showMessage(decodeURIComponent(message), 
          message.includes("Invalid") || 
          message.includes("expired") || 
          message.includes("error"));
      }
    };
    
    // Resend OTP functionality
    document.getElementById('resend-otp').addEventListener('click', function() {
      const email = document.getElementById('email-field').value;
      if (email) {
        // Disable resend button and show countdown
        this.style.display = 'none';
        const countdownElement = document.getElementById('countdown');
        countdownElement.style.display = 'inline';
        
        let secondsLeft = 60;
        countdownElement.textContent = `Resend in ${secondsLeft}s`;
        
        const countdownInterval = setInterval(() => {
          secondsLeft--;
          countdownElement.textContent = `Resend in ${secondsLeft}s`;
          
          if (secondsLeft <= 0) {
            clearInterval(countdownInterval);
            countdownElement.style.display = 'none';
            this.style.display = 'inline';
          }
        }, 1000);
        
        // Send request to resend OTP
        fetch('resend_otp.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: `email=${encodeURIComponent(email)}`
        })
        .then(response => response.text())
        .then(data => {
          showMessage('Verification code resent to your email');
        })
        .catch(error => {
          showMessage('Failed to resend verification code', true);
        });
      }
    });
    
    // Show message popup
    function showMessage(message, isError = false) {
      const overlay = document.createElement('div');
      overlay.className = 'popup-overlay';
      
      const popupBox = document.createElement('div');
      popupBox.className = isError ? 'popup-box error' : 'popup-box';
      
      const paragraph = document.createElement('p');
      paragraph.textContent = message;
      
      popupBox.appendChild(paragraph);
      overlay.appendChild(popupBox);
      document.body.appendChild(overlay);
      
      overlay.addEventListener('click', function() {
        document.body.removeChild(overlay);
      });
      
      // Auto dismiss after 5 seconds
      setTimeout(() => {
        if (document.body.contains(overlay)) {
          document.body.removeChild(overlay);
        }
      }, 5000);
    }
    
    // Dismiss popup
    function dismissPopup() {
      const popup = document.querySelector('.popup-overlay');
      if (popup) popup.remove();
    }
  </script>
</body>
</html>