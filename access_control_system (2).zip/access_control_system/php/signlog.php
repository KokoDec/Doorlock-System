<?php
ob_start();
session_start();

// If user is already logged in, redirect to index.php
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$message = isset($_GET['message']) ? $_GET['message'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login Page</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
  <link rel="stylesheet" href="../cs/styles.css" />
  <script>
    // Prevent browser back navigation after logout
    // Execute immediately, don't wait for load event
    (function() {
      // Disable browser back button
      window.history.pushState(null, "", window.location.href);
      window.onpopstate = function() {
        window.history.pushState(null, "", window.location.href);
      };
      
      // If back button is attempted, revalidate session immediately
      window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
          // Page was loaded from cache (back button)
          window.location.reload(); // Force reload from server
        }
      });
    })();
  </script>
</head>
<body>
  <div class="main-container">
    <!-- Left Panel -->
    <div class="left-panel">
      <div class="left-panel-content">
        <div class="content-top">
          <h1>Your Digital Key Starts Here.</h1>
          <p>
            With just one login, experience secure and seamless access<br />
            to your smart door system—anytime, anywhere.
          </p>
        </div>
        <div class="image-container">
          <img src="../pictures/orig.png" alt="Login Illustration" class="login-image" />
        </div>
      </div>
    </div>

    <!-- Right Panel -->
    <div class="right-panel">
      <form class="login-form" method="POST" action="signlog_process.php">
        <h2>Log In</h2>
        <div class="form-body">
          <label for="email">E-mail</label>
          <input type="email" id="email" name="email" placeholder="Enter your email" required />

          <div class="password-field">
            <input type="password" id="password" name="password" placeholder="Enter your password" required />
            <span class="toggle-eye" onclick="togglePassword(this)">
              <i class="fas fa-eye"></i>
            </span>
          </div>

          <button type="submit" class="submit-btn">SIGN IN</button>

          <div class="auth-links">
          <a href="forgotpass.php" class="forgot">Forgot password?</a>
            <a href="signup.php" class="signup-link">Sign up</a>
          </div>
        </div>
      </form>

      <div class="terms">
        <a href="#" onclick="openTerms()">Terms and Conditions</a>
      </div>
    </div>
  </div>

  <!-- Notification Popup -->
  <?php if ($message): ?>
    <div class="popup-overlay" onclick="dismissPopup()">
      <div class="popup-box error">
        <p><?php echo $message; ?></p>
      </div>
    </div>
  <?php endif; ?>

  <!-- Terms Modal -->
  <div id="termsModal" class="modal hidden">
    <div class="modal-content scrollable">
      <span class="close-btn" onclick="closeTerms()">&times;</span>
      <p><strong>Terms and Conditions</strong></p>
<p><strong>Effective Date:</strong></p>
<p>
Welcome to the Door Lock Web Admin. These Terms and Conditions ("Terms") govern your
access to and use of our website and all features, technologies, and content we provide
(collectively, the "Services"). By accessing, creating an account, or using our Services in any
way, you agree to these Terms. If you do not agree, please do not use our Services.
</p>

<br>

<p><strong>Account Registration and Responsibilities</strong></p>
<p>
As an administrator overseeing the Services—particularly those involving smart door access
control—you are responsible for ensuring that all user accounts are registered with accurate,
current, and complete information. You must verify the integrity of user data during registration
and confirm that users maintain up-to-date profiles.
</p>
<p>
Before gaining access to the website or any system functionality, explicit permission from a
higher-level administrator is required. No admin or user should be granted access without
proper approval and documentation of said authorization.
</p>
<p>
Admins must enforce strict account confidentiality protocols. This includes monitoring for any
signs of credential sharing and ensuring that users do not disclose their usernames or
passwords to others.
</p>
<p>
It is your duty to promptly respond to and investigate any reports of unauthorized account
activity or security breaches. Appropriate actions, such as locking accounts, resetting
passwords, or escalating to security teams, must be taken immediately to mitigate potential
risks.
</p>
<p>
Failure to uphold these standards may compromise system integrity and will be subject to
review and possible administrative action.
</p>

<br>

<p><strong>Permitted Use of Services</strong></p>
<p>
The Door Lock Web Admin uses a secure three-step login process: username/password login,
email code verification, and approval from a high-level administrator. Access to the Admin
Dashboard is granted only after completing all steps.
</p>
<p>
Every successful login is recorded in the dashboard, including the exact time and date of
access, for tracking and monitoring purposes. All admin actions are also logged with
timestamps.
</p>

<br>

<p><strong>User-Generated Input and Password Security</strong></p>
<p>
As part of administering the Door Lock Web platform, administrators are responsible for
overseeing the secure creation, storage, and management of user-generated passwords and
PINs used to control smart door systems.
</p>
<p>
Passwords and PINs are classified as sensitive user-generated content and are fundamental to
the security of both the individual user's system and the platform as a whole.
</p>
<p>
Admins must enforce the following policies:
<ul>
  <li>Ensure that users set strong, complex passwords or PINs during registration or device setup.</li>
  <li>Actively discourage the use of weak, common, or misleading passwords (e.g., "1234", "admin", or device serial numbers).</li>
  <li>Prevent password reuse across multiple accounts or devices, where possible.</li>
  <li>Immediately revoke or reset access credentials if shared with unauthorized users or compromised in any way.</li>
</ul>
</p>

<br>

<p><strong>Ownership and Intellectual Property</strong></p>
<p>
All elements of the Door Lock System, including but not limited to the software code, user
interface, content, logos, trademarks, system designs, and underlying technology, are the
exclusive property of Admin door login or are used under license from third parties. Users are
granted a limited, non-exclusive, and non-transferable license to access and use the system
solely for authorized, non-commercial purposes. Any modification, reproduction, redistribution,
republication, or creation of derivative works based on our system or intellectual property is
strictly prohibited without our prior written consent.
</p>

<br>

<p><strong>Privacy and Data Usage</strong></p>
<p>
We take your privacy seriously. By using the Services, you agree to the collection, storage, and
processing of your personal data, including login credentials, usage activity, and device
interaction data. This information is used to operate and improve the Services, ensure security,
and comply with legal obligations. For details on how we handle your data, please refer to our
Privacy Policy, which is incorporated into these Terms by reference.
</p>

<br>

<p><strong>Service Availability and System Performance</strong></p>
<p>
We aim to provide consistent, high-quality access to the Services. However, we do not
guarantee that the Services will be available at all times or that access will be uninterrupted or
error-free. The system may occasionally become unavailable due to maintenance, updates,
technical failures, or circumstances beyond our control. While we strive to resolve such issues
promptly, we disclaim any liability for delays, interruptions, or temporary outages.
</p>

<br>

<p><strong>Limitation of Liability</strong></p>
<p>
To the fullest extent permitted by law, Door Lock Web Admins are not liable for any direct,
indirect, incidental, consequential, or special damages arising from use of the Services. This
includes issues such as unauthorized access, data loss, system failures, or any
physical/property damage from smart door malfunctions.
</p>
<p>
Admins are responsible for ensuring all devices are installed and managed securely and
lawfully. This includes:
<ul>
  <li>Using strong, non-misleading passwords or PINs.</li>
  <li>Keeping login credentials secure and confidential.</li>
  <li>Following recovery protocols if access is lost.</li>
</ul>
</p>
<p>
If an admin forgets their password or creates a misleading one that results in access issues,
delays, or security vulnerabilities, they are solely responsible for the outcome.
</p>

<br>

<p><strong>Suspension and Termination of Access</strong></p>
<p>
We reserve the right to suspend or terminate your account or restrict access to the Services at
our sole discretion, without prior notice, if you violate these Terms or engage in any activity that
compromises the integrity, safety, or security of our platform or users. You may terminate your
account at any time by contacting us or through the account settings panel on the website or
app. Upon termination, your access to Door Lock Web Admin and related data may be
permanently removed.
</p>

<br>

<p><strong>Updates and Modifications to Terms</strong></p>
<p>
We may update these Terms from time to time to reflect changes in our business, technology, or
legal obligations. Any material changes will be communicated to you via email, in-app
notifications, or posted directly on our website. Continued use of the Services after such
changes take effect constitutes your agreement to the revised Terms.
</p>

<br>

<p><strong>Jurisdiction and Governing Law</strong></p>
<p>
These Terms are governed by and construed in accordance with the laws of the Republic of the
Philippines. By using the Services, you agree to submit to the exclusive jurisdiction of the courts
located in the Philippines in the event of any dispute, claim, or legal proceeding arising under or
related to these Terms.
</p>

<br>

<p><strong>Contact Information</strong><br>
Admin door login / <a href="mailto:bryancasipe38@gmail.com">bryancasipe38@gmail.com</a>
</p>

    </div>
  </div>

  <!-- Scripts -->
  <script>
    function togglePassword(icon) {
      const input = icon.previousElementSibling;
      const isPasswordVisible = input.type === "password";
      input.type = isPasswordVisible ? "text" : "password";
      icon.innerHTML = isPasswordVisible ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
      icon.classList.toggle('clicked');
    }

    function dismissPopup() {
      const popup = document.querySelector('.popup-overlay');
      if (popup) popup.remove();
    }

    function openTerms() {
      document.getElementById("termsModal").classList.remove("hidden");
    }

    function closeTerms() {
      document.getElementById("termsModal").classList.add("hidden");
    }
  </script>
</body>
</html>

<?php ob_end_flush(); ?>
