<?php
// changepassword.php

include('conn.php'); // Database connection
session_start(); // Start the session to check OTP verification

if (!isset($_SESSION['otp'])) {
    header("Location: forgotpass.php?message=OTP verification required.");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Sanitize inputs
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);

    if ($new_password !== $confirm_password) {
        header("Location: forgotpass.php?message=Passwords do not match!");
        exit;
    }

    // Check if user exists and is approved
    $stmt = $conn->prepare("SELECT * FROM sign_up WHERE email = ? AND status = 'approved'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Hash the password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Update the password
        $update = $conn->prepare("UPDATE sign_up SET password = ? WHERE email = ?");
        $update->bind_param("ss", $hashed_password, $email);
        $update->execute();

        // OTP verification successful, clear OTP session and redirect
        unset($_SESSION['otp']);

        // Redirect with success message
        header("Location: forgotpass.php?message=Password changed successfully.");
        exit;
    } else {
        header("Location: forgotpass.php?message=No approved account found with this email.");
        exit;
    }
}
?>
