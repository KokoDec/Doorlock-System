<?php
include('conn.php');

header('Content-Type: application/json');

// Check if ID parameter is set and is numeric
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $log_id = intval($_GET['id']);
    
    // Prepare and execute query to get log details
    $sql = "SELECT id, status, date FROM logs WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $log_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Fetch the log data
        $log = $result->fetch_assoc();
        
        // Format date and time for display
        $log['formatted_date'] = date('Y-m-d', strtotime($log['date']));
        $log['formatted_time'] = date('H:i:s', strtotime($log['date']));
        
        // Return the log data as JSON
        echo json_encode([
            'success' => true,
            'log' => $log
        ]);
    } else {
        // Log not found
        echo json_encode([
            'success' => false,
            'message' => 'Log not found'
        ]);
    }
    
    $stmt->close();
} else {
    // Invalid ID parameter
    echo json_encode([
        'success' => false,
        'message' => 'Invalid log ID'
    ]);
}

$conn->close();
?> 