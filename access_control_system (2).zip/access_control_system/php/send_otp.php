<?php
// Include the PHPMailer library
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // Make sure to include this if you installed PHPMailer via Composer

// Include the connection file
include('conn.php');

// Retrieve email and password from the POST request
// Sanitize input
$email = $_POST['email'];
$password = isset($_POST['password']) ? $_POST['password'] : ''; // Make password optional
$isResend = isset($_POST['resend']) && $_POST['resend'] === 'true';

// If it's not a resend request, check if email already exists
if (!$isResend) {
    $check_stmt = $conn->prepare("SELECT * FROM sign_up WHERE email = ?");
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        echo "Email already exists.";
        exit;
    }
}

// Generate OTP (6-digit random number)
$otp = rand(100000, 999999);

// Hash the password (optional, for future use in login)
$hashed_password = !empty($password) ? password_hash($password, PASSWORD_DEFAULT) : '';

// Step 1: Check if email already exists in the 'sign_up' table
$sql_check = "SELECT id FROM sign_up WHERE email = ?";
$stmt_check = $conn->prepare($sql_check);

if ($stmt_check === false) {
    die('Error preparing query: ' . $conn->error); // Handle the error if prepare fails
}

$stmt_check->bind_param('s', $email);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    // If email exists, update the OTP
    $sql_update_otp = "UPDATE sign_up SET otp = ?, otp_status = 'pending' WHERE email = ?";
    $stmt = $conn->prepare($sql_update_otp);
    
    if ($stmt === false) {
        die('Error preparing query: ' . $conn->error); // Handle the error if prepare fails
    }

    // Bind the parameters and execute the query
    $stmt->bind_param('is', $otp, $email);

    if ($stmt->execute()) {
        // Send OTP using PHPMailer
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Use Gmail SMTP
            $mail->SMTPAuth = true;
            $mail->Username = 'bryancasipe38@gmail.com'; // Your Gmail email address
            $mail->Password = 'cdgb kksa orll jbhx'; // Your Gmail password (consider using app-specific password for security)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('your_email@gmail.com', 'Your Name');
            $mail->addAddress($email); // Add recipient email

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your OTP Code';
            $mail->Body    = "Your OTP code is: $otp";

            $mail->send();
            echo "otp_sent"; // Return success message
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Error saving OTP to database.";
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // If email doesn't exist and it's a resend request, return an error
    if ($isResend) {
        echo "Email does not exist.";
        exit;
    }
    
    // Otherwise, insert new user and send OTP
    $sql_insert = "INSERT INTO sign_up (email, password, otp, otp_status) VALUES (?, ?, ?, 'pending')";
    $stmt_insert = $conn->prepare($sql_insert);
    
    if ($stmt_insert === false) {
        die('Error preparing query: ' . $conn->error); // Handle the error if prepare fails
    }

    // Bind the parameters and execute the query
    $stmt_insert->bind_param('sss', $email, $hashed_password, $otp);

    if ($stmt_insert->execute()) {
        // Send OTP using PHPMailer
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Use Gmail SMTP
            $mail->SMTPAuth = true;
            $mail->Username = 'bryancasipe38@gmail.com'; // Your Gmail email address
            $mail->Password = 'cdgb kksa orll jbhx'; // Your Gmail password (consider using app-specific password for security)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('your_email@gmail.com', 'Your Name');
            $mail->addAddress($email); // Add recipient email

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your OTP Code';
            $mail->Body    = "Your OTP code is: $otp";

            $mail->send();
            echo "otp_sent"; // Return success message
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Error registering new user.";
    }

    $stmt_insert->close();
}

$stmt_check->close();
$conn->close();
?>
