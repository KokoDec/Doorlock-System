<?php
session_start();
include('conn.php'); // Database connection
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (isset($_GET['email'])) {
    $email = filter_var($_GET['email'], FILTER_SANITIZE_EMAIL);

    try {
        // Check if the email exists and is approved
        $stmt = $conn->prepare("SELECT id FROM sign_up WHERE email = ? AND status = 'approved'");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $otp = rand(100000, 999999); // Generate a 6-digit OTP
            $expiry = date("Y-m-d H:i:s", strtotime("+15 minutes")); // OTP expiry time

            // Store the OTP in the database
            $otp_stmt = $conn->prepare("UPDATE sign_up SET otp = ?, otp_expiry = ? WHERE id = ?");
            $otp_stmt->bind_param("ssi", $otp, $expiry, $user['id']);
            if ($otp_stmt->execute()) {
                // Send OTP via email
                $mail = new PHPMailer(true);

                try {
                    //Server settings
                    $mail->SMTPDebug = SMTP::DEBUG_OFF; // Set to SMTP::DEBUG_SERVER for more detailed output
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com'; // Replace with your SMTP server
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'bryancasipe38@gmail.com'; // Replace with your Gmail address
                    $mail->Password   = 'cdgb kksa orll jbhx'; // Replace with your Gmail password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS
                    $mail->Port       = 587;

                    //Recipients
                    $mail->setFrom('your_email@gmail.com', 'Your Website Name'); // Replace
                    $mail->addAddress($email);

                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = 'Your Password Reset OTP';
                    $mail->Body    = '<p>Your One-Time Password (OTP) for password reset is:</p> <h2>' . $otp . '</h2> <p>This OTP will expire in 15 minutes.</p>';
                    $mail->AltBody = 'Your One-Time Password (OTP) for password reset is: ' . $otp . '. This OTP will expire in 15 minutes.';

                    $mail->send();
                    header("Location: forgotpass.php?message=OTP sent successfully! Please check your email.&otp_sent=success&email=" . urlencode($email));
                    exit();

                } catch (Exception $e) {
                    error_log("PHPMailer Error sending OTP to " . $email . ": " . $mail->ErrorInfo);
                    header("Location: forgotpass.php?message=Failed to send OTP. Please try again later.&isError=true");
                    exit();
                }
            } else {
                error_log("Error updating OTP in database for user ID " . $user['id'] . ": " . $otp_stmt->error);
                header("Location: forgotpass.php?message=Database error. Please try again.&isError=true");
                exit();
            }

        } else {
            error_log("No approved account found with email: " . $email);
            header("Location: forgotpass.php?message=No approved account found with this email.&isError=true");
            exit();
        }

    } catch (Exception $e) {
        error_log("Database query error: " . $e->getMessage());
        header("Location: forgotpass.php?message=An unexpected error occurred. Please try again.&isError=true");
        exit();
    } finally {
        if (isset($stmt)) {
            $stmt->close();
        }
        if (isset($otp_stmt)) {
            $otp_stmt->close();
        }
        if (isset($conn)) {
            $conn->close();
        }
    }
} else {
    header("Location: forgotpass.php?message=Invalid request.&isError=true");
    exit();
}
?>