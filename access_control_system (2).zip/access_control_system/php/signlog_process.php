<?php
session_start();
include('conn.php');

// Get email & password from form
$email = $_POST['email'];
$password = $_POST['password'];

// Check if the email exists in the database
$sql = "SELECT * FROM sign_up WHERE email = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    // Verify password
    if (!password_verify($password, $user['password'])) {
        header('Location: signlog.php?message=Incorrect password.');
        exit;
    }

    // Check OTP verification
    if ($user['otp_status'] !== 'verified') {
        header('Location: signlog.php?message=Your account has not been verified by OTP.');
        exit;
    }

    // Check admin approval
    if ($user['status'] !== 'approved') {
        header('Location: signlog.php?message=Your account is not yet approved by admin.');
        exit;
    }

    // ✅ Log successful login in `weblog` table
    $log_sql = "INSERT INTO weblog (email, access_time) VALUES (?, NOW())";
    $log_stmt = $conn->prepare($log_sql);

    if ($log_stmt) {
        $log_stmt->bind_param("s", $email);
        $log_stmt->execute();
    } else {
        error_log("Logging failed: " . $conn->error);
    }

    // Set session and redirect
    $_SESSION['email'] = $email;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['last_activity'] = time(); // Track when the user last had activity
    header('Location: index.php');
    exit;
} else {
    header('Location: signlog.php?message=Email not found.');
    exit;
}
?>
