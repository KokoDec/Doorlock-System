import serial
import mysql.connector
from datetime import datetime
import smtplib
from email.mime.text import MIMEText

# 📧 Email Configuration
EMAIL_SENDER = "bryancasipe38@gmail.com"
EMAIL_PASSWORD = "cdgb kksa orll jbhx"  # Palitan ng tamang App Password
EMAIL_RECEIVER = "insigne.jerald.dalicon@gmail.com"

def send_email(status, date):
    subject = f"🔔 Door Access Notification: {status}"
    body = f"""
    Door Lock System Notification

    Status: {status}
    Date & Time: {date}

    Regards,
    Door Lock System
    """

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = EMAIL_SENDER
    msg["To"] = EMAIL_RECEIVER

    try:
        print("📤 Sending email...")  # Debug print
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(EMAIL_SENDER, EMAIL_PASSWORD)
        server.sendmail(EMAIL_SENDER, EMAIL_RECEIVER, msg.as_string())
        server.quit()
        print("📩 Email sent successfully!")  # Confirm email was sent
    except Exception as e:
        print("❌ Email sending failed:", str(e))  # Show error if failed

# ✅ Connect to Arduino
arduino = serial.Serial('COM3', 9600)

# ✅ Connect to MySQL
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="access_logs"
)
cursor = db.cursor()

while True:
    data = arduino.readline().decode().strip()
    if data:
        print(f"🛠️ Received from Arduino: {data}")  # Debug print

        # ✅ Generate timestamp
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # ✅ Insert into MySQL
        sql = "INSERT INTO logs (status, date) VALUES (%s, %s)"
        cursor.execute(sql, (data, current_time))
        db.commit()

        print("✅ LOG INSERTED into MySQL")  # Debug print

        # ✅ Send Email Notification
        send_email(data, current_time)
