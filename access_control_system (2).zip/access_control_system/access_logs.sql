-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2025 at 01:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `access_logs`
--

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `status`, `date`) VALUES
(52, 'Expected UID: 93F94B16', '2025-03-25 21:45:26'),
(53, 'Scanned UID: 93F94B16', '2025-03-25 21:45:26'),
(54, 'LOG:ADMIN_ACCESS_GRANTED', '2025-03-25 21:45:30'),
(55, 'WRONG_PASSWORD', '2025-03-25 21:51:34'),
(56, 'ACCESS_GRANTED', '2025-03-25 21:51:47'),
(57, 'ADMIN_ACCESS_GRANTED', '2025-03-25 21:52:06'),
(58, 'ADMIN_UPDATED_PASSWORD', '2025-03-25 21:52:36'),
(59, 'WRONG_PASSWORD', '2025-03-25 21:52:46'),
(60, 'WRONG_PASSWORD', '2025-03-25 21:52:51'),
(61, 'WRONG_PASSWORD', '2025-03-25 21:52:56'),
(62, 'WRONG_PASSWORD', '2025-03-25 21:53:00'),
(63, 'WRONG_PASSWORD', '2025-03-25 21:53:07'),
(64, 'LOCKED', '2025-03-25 21:53:09'),
(65, 'WRONG_PASSWORD', '2025-03-25 22:35:30'),
(66, 'WRONG_PASSWORD', '2025-03-25 22:35:34'),
(67, 'WRONG_PASSWORD', '2025-03-25 22:35:37'),
(68, 'WRONG_PASSWORD', '2025-03-25 22:35:41'),
(69, 'WRONG_PASSWORD', '2025-03-25 22:35:45'),
(70, 'USER_LOCKED', '2025-03-25 22:35:47'),
(71, 'LOCKED', '2025-03-25 22:35:49'),
(72, 'ADMIN_ACCESS_GRANTED', '2025-03-25 22:36:38'),
(73, 'ADMIN_ACCESS_DENIED', '2025-03-25 22:38:22'),
(74, 'WRONG_PASSWORD', '2025-03-25 22:38:49'),
(75, 'ACCESS_DENIED', '2025-03-25 22:39:37'),
(76, 'WRONG_PASSWORD', '2025-03-25 22:39:48'),
(77, 'WRONG_PASSWORD', '2025-03-25 22:39:53'),
(78, 'WRONG_PASSWORD', '2025-03-25 22:39:57'),
(79, 'LOCKED', '2025-03-25 22:39:59'),
(80, 'ACCESS_GRANTED', '2025-03-25 23:44:11'),
(81, 'ADMIN_ACCESS_GRANTED', '2025-03-25 23:44:31'),
(82, 'ACCESS_GRANTED', '2025-03-25 23:54:27'),
(83, 'ACCESS_GRANTED', '2025-03-25 23:55:50'),
(84, 'ACCESS_GRANTED', '2025-03-25 23:57:00'),
(85, 'ACCESS_GRANTED', '2025-03-26 00:02:41'),
(86, 'ACCESS_GRANTED', '2025-03-26 00:03:56'),
(87, 'ACCESS_GRANTED', '2025-03-26 00:04:54'),
(88, 'WRONG_PASSWORD', '2025-03-26 00:05:37'),
(89, 'WRONG_PASSWORD', '2025-03-26 00:06:04'),
(90, 'ADMIN_UPDATED_PASSWORD', '2025-03-26 00:08:11'),
(91, 'ACCESS_GRANTED', '2025-03-26 00:10:33'),
(92, 'ACCESS_GRANTED', '2025-03-26 00:11:46'),
(93, 'ACCESS_GRANTED', '2025-03-27 10:32:07'),
(94, 'WRONG_PASSWORD', '2025-03-27 10:36:14'),
(95, 'ACCESS_GRANTED', '2025-03-27 10:36:23'),
(96, 'ACCESS_GRANTED', '2025-03-27 10:37:02'),
(97, 'WRONG_PASSWORD', '2025-03-27 10:37:26'),
(98, 'ACCESS_GRANTED', '2025-03-27 10:37:34'),
(99, 'ACCESS_GRANTED', '2025-03-27 10:39:14'),
(100, 'ACCESS_GRANTED', '2025-03-27 11:33:06'),
(101, 'ACCESS_DENIED', '2025-03-27 11:33:28'),
(102, 'ACCESS_GRANTED', '2025-03-27 13:10:06'),
(103, 'ADMIN_ACCESS_GRANTED', '2025-03-27 13:11:20');

-- --------------------------------------------------------

--
-- Table structure for table `log_entries`
--

CREATE TABLE `log_entries` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE `sign_up` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `otp` int(6) DEFAULT NULL,
  `otp_status` enum('pending','verified') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`id`, `email`, `password`, `status`, `created_at`, `otp`, `otp_status`) VALUES
(3, 'enovejas.ahramae.erracho@gmail.com', '$2y$10$g3G97icoFkyH0OP8NqgZne619puD2deRlXl.OEhHukbIn7irdlIqC', 'approved', '2025-05-04 09:42:10', 327709, 'verified'),
(4, 'caballo.ellamae.c@gmail.com', '$2y$10$LBKhIfg2jTzwoAC60Oqo5u6/BZkp497He8TLftGnplopOUYqvBZhW', 'rejected', '2025-05-04 09:43:15', 908959, 'verified'),
(5, 'varca.peterjohn.i@gmail.com', '$2y$10$RqBx22jDt5TA1c2Y6hBqEOLmy20AkF2FMbcmjKQYEsaQ5THNX8H9m', 'pending', '2025-05-04 09:44:13', 355218, 'verified'),
(6, 'bryancasipe38@gmail.com', '$2y$10$kHOUFjk8ZKdmLIzMX12CtucRcYXT2PwJqnfvg6JF6W4l/fsf5JkbO', 'approved', '2025-05-08 11:13:59', 475873, 'verified'),
(8, 'gojou4670@gmail.com', '$2y$10$RoEz1QJbu7Ca..XRGhUE2ubPRXdRensxOMbYSIisvJvTzoqoH4bSG', 'approved', '2025-05-11 11:31:57', 911027, 'verified');

-- --------------------------------------------------------

--
-- Table structure for table `weblog`
--

CREATE TABLE `weblog` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `access_time` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `weblog`
--

INSERT INTO `weblog` (`id`, `email`, `access_time`) VALUES
(1, 'bryancasipe38@gmail.com', '2025-05-04 18:22:28'),
(2, 'bryancasipe38@gmail.com', '2025-05-04 18:22:48'),
(3, 'bryancasipe38@gmail.com', '2025-05-04 18:33:31'),
(4, 'bryancasipe38@gmail.com', '2025-05-04 18:46:09'),
(5, 'enovejas.ahramae.erracho@gmail.com', '2025-05-05 23:33:18'),
(6, 'bryancasipe38@gmail.com', '2025-05-06 00:04:28'),
(7, 'bryancasipe38@gmail.com', '2025-05-06 00:51:41'),
(8, 'bryancasipe38@gmail.com', '2025-05-06 13:17:20'),
(9, 'bryancasipe38@gmail.com', '2025-05-06 13:18:03'),
(10, 'bryancasipe38@gmail.com', '2025-05-08 15:05:28'),
(11, 'bryancasipe38@gmail.com', '2025-05-08 17:48:11'),
(12, 'bryancasipe38@gmail.com', '2025-05-08 18:44:03'),
(13, 'enovejas.ahramae.erracho@gmail.com', '2025-05-08 19:15:48'),
(14, 'bryancasipe38@gmail.com', '2025-05-08 19:37:50'),
(15, 'bryancasipe38@gmail.com', '2025-05-11 14:26:33'),
(16, 'bryancasipe38@gmail.com', '2025-05-11 18:31:46'),
(17, 'bryancasipe38@gmail.com', '2025-05-11 18:36:07'),
(18, 'bryancasipe38@gmail.com', '2025-05-11 18:40:19'),
(19, 'bryancasipe38@gmail.com', '2025-05-11 18:40:25'),
(20, 'bryancasipe38@gmail.com', '2025-05-11 18:40:44'),
(21, 'bryancasipe38@gmail.com', '2025-05-11 18:40:54'),
(22, 'bryancasipe38@gmail.com', '2025-05-11 18:41:40'),
(23, 'bryancasipe38@gmail.com', '2025-05-11 18:41:48'),
(24, 'bryancasipe38@gmail.com', '2025-05-11 18:44:24'),
(25, 'bryancasipe38@gmail.com', '2025-05-11 19:00:06'),
(26, 'bryancasipe38@gmail.com', '2025-05-11 19:33:10'),
(27, 'gojou4670@gmail.com', '2025-05-11 19:33:40'),
(28, 'bryancasipe38@gmail.com', '2025-05-11 19:40:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_entries`
--
ALTER TABLE `log_entries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sign_up`
--
ALTER TABLE `sign_up`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `weblog`
--
ALTER TABLE `weblog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `log_entries`
--
ALTER TABLE `log_entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sign_up`
--
ALTER TABLE `sign_up`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `weblog`
--
ALTER TABLE `weblog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
